# Third-party and evidence notice

Copyright 2026 Bingjie Zhu

Project-owned source, documentation, fixtures, and the bundled synthetic benchmark
are licensed under the PolyForm Noncommercial License 1.0.0. Commercial use requires
a separate written license. See [LICENSE](LICENSE) and
[COMMERCIAL-LICENSE.md](COMMERCIAL-LICENSE.md). This is source-available. It is not
OSI Open Source.

Runtime dependencies are FastAPI (MIT), Pydantic (MIT), rfc8785.py (Apache-2.0),
Uvicorn (BSD-3-Clause), and their locked transitive dependencies. AgentTeams is an Apache-2.0 upstream
integration target. A complete Git bundle of the exact v1.2.2 upstream tag is
redistributed under `vendor/agentteams/` solely for offline source reconstruction;
its upstream `LICENSE` remains inside that bundle. OrgRebase's AgentTeams manifests,
locks and adapters remain project-authored integration code.

All bundled business data and evaluation cases are synthetic. `LOCAL_DETERMINISTIC`,
`SYNTHETIC_FIXTURE`, `PASS_STATIC`, `LIVE_AGENTTEAMS`, and `NOT_RUN` are deliberately
different evidence classes and must not be conflated.

The one-command frozen semifinal replay verifies retained receipts and makes no
new model or cloud call. A fresh current Golden run can use the native structured
Vertex adapter with `gemini-3.7-flash`; its output is advisory-only and never gains
approval or canonical-write authority. The separate Core AgentTeams compatibility
profile that uses the OpenAI-compatible `google/gemini-3.1-flash-lite` coordinate is
retained, non-current evidence. Ollama is an optional offline/CI route, not the
current frozen Golden model evidence. Credentials, project identifiers,
project-scoped endpoints, raw prompts, and raw model output are excluded from the
public release.
