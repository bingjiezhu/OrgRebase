"""OrgRebase deterministic enterprise change-consistency runtime."""

__version__ = "0.4.0"

from orgrebase.service import OrgRebaseService

__all__ = ["OrgRebaseService"]
