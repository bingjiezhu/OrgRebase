"""FastAPI surface and zero-build-dependency Change Console."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from threading import Lock
from typing import Any

from fastapi import FastAPI, Header, HTTPException
from fastapi.encoders import jsonable_encoder
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from orgrebase import __version__
from orgrebase.digest import sha256_digest
from orgrebase.domain import AuthorizationError, FreshnessError, IntegrityError
from orgrebase.resource_paths import runtime_asset_path
from orgrebase.service import OrgRebaseService
from orgrebase.workspace.service import (
    CONTROLLED_LOCAL_HEADER_IDENTITY,
    WorkspaceService,
)

PROJECT_ROOT = Path(__file__).resolve().parents[2]
PACKAGED_CONSOLE_DIR = Path(__file__).resolve().parent / "static"
CONSOLE_DIR = PACKAGED_CONSOLE_DIR if PACKAGED_CONSOLE_DIR.is_dir() else PROJECT_ROOT / "demo" / "console"
SOURCE_RELEASE_FACTS_PATH = PROJECT_ROOT / "evidence" / "release-facts.json"
PACKAGED_RELEASE_FACTS_PATH = Path(__file__).resolve().parent / "_assets/evidence/release-facts.json"
RELEASE_FACTS_PATH = (
    SOURCE_RELEASE_FACTS_PATH if SOURCE_RELEASE_FACTS_PATH.is_file() else PACKAGED_RELEASE_FACTS_PATH
)
GOLDEN_EVIDENCE_ROOT = PROJECT_ROOT / "evidence" / "golden-competition" / "latest" / "pilot"
OPERATING_MODEL_ASSET = Path(
    "benchmark/quote-value-v0.1/public/current-process-baseline.json"
)
OPERATING_MODEL_STEP_IDS = (
    "quote-step:intake",
    "quote-step:product-confirmation",
    "quote-step:legal-confirmation",
    "quote-step:finance-confirmation",
    "quote-step:composition",
    "quote-step:delivery-acceptance",
    "quote-step:change-impact",
    "quote-step:selective-update",
)


def _active_golden_evidence_root() -> Path:
    """Resolve the one read-only Golden root shared by every API projection."""

    configured = os.environ.get("ORGREBASE_GOLDEN_EVIDENCE_ROOT", "").strip()
    return Path(configured).expanduser().resolve() if configured else GOLDEN_EVIDENCE_ROOT


def _run_oac_bound_shadow_independent_verifier(
    *,
    root: str | Path,
    pack: str | Path,
    frozen_golden: str | Path,
    fencing_reference: str | Path | None,
) -> dict[str, Any]:
    """Run the product-independent verifier as a separate Python process."""

    script = PROJECT_ROOT / "scripts" / "verify_oac_bound_shadow_execution.py"
    if not script.is_file() or fencing_reference is None:
        raise RuntimeError("OAC_SHADOW_INDEPENDENT_VERIFIER_UNAVAILABLE")
    try:
        completed = subprocess.run(
            [
                sys.executable,
                str(script),
                "--root",
                str(root),
                "--pack",
                str(pack),
                "--frozen-golden",
                str(frozen_golden),
                "--fencing-reference",
                str(fencing_reference),
            ],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
        result = json.loads(completed.stdout)
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
        raise RuntimeError("OAC_SHADOW_INDEPENDENT_VERIFIER_FAILED") from exc
    if completed.returncode != 0 or not isinstance(result, dict):
        raise RuntimeError("OAC_SHADOW_INDEPENDENT_VERIFIER_FAILED")
    return result


def _golden_evidence_status(
    root: Path,
    *,
    current_run_id: str,
) -> dict[str, Any]:
    """Project a frozen pack receipt without treating it as business truth."""

    result: dict[str, Any] = {
        "schema_version": "orgrebase.golden-evidence-status.v1",
        "status": "UNAVAILABLE",
        "current_run_id": current_run_id,
        "frozen_run_id": None,
        "same_run": False,
        "entry_count": None,
        "pack_digest": None,
        "verification_mode": None,
        "claim_boundary": ("READ_ONLY_FROZEN_EVIDENCE_STATUS_NOT_CANONICAL_BUSINESS_TRUTH"),
    }
    try:
        manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
        verification = json.loads((root / "verification.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return result
    if not isinstance(manifest, dict) or not isinstance(verification, dict):
        return {**result, "status": "FAIL"}

    manifest_body = {key: value for key, value in manifest.items() if key != "digest"}
    files = manifest.get("files")
    frozen_run_id = manifest.get("run_id")
    valid = (
        manifest.get("digest") == sha256_digest(manifest_body)
        and isinstance(files, dict)
        and verification.get("status") == "PASS"
        and verification.get("failures") == []
        and verification.get("run_id") == frozen_run_id
        and verification.get("entry_count") == files.get("entry_count")
        and verification.get("pack_digest") == files.get("pack_digest")
        and verification.get("product_imports") == 0
    )
    same_run = bool(valid and frozen_run_id == current_run_id)
    return {
        **result,
        "status": "PASS" if same_run else ("STALE" if valid else "FAIL"),
        "frozen_run_id": frozen_run_id,
        "same_run": same_run,
        "entry_count": verification.get("entry_count") if valid else None,
        "pack_digest": verification.get("pack_digest") if valid else None,
        "verification_mode": verification.get("verification_mode") if valid else None,
    }


def _operating_model_view(path: Path | None = None) -> dict[str, Any]:
    """Read the declared quote operating model without borrowing run evidence."""

    selected = path or runtime_asset_path(OPERATING_MODEL_ASSET)
    try:
        payload = json.loads(selected.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError("OPERATING_MODEL_UNAVAILABLE") from exc
    if not isinstance(payload, dict):
        raise RuntimeError("OPERATING_MODEL_INVALID")
    steps = payload.get("process_steps")
    if (
        payload.get("schema_version")
        != "orgrebase.workspace-current-process-baseline.v1"
        or payload.get("status") != "NOT_RUN"
        or payload.get("evidence_class") != "NOT_RUN"
        or payload.get("primary_user") != "Enterprise Quote Operator"
        or payload.get("primary_deliverable") != "Enterprise Quote"
        or not isinstance(steps, list)
        or tuple(step.get("id") for step in steps if isinstance(step, dict))
        != OPERATING_MODEL_STEP_IDS
    ):
        raise RuntimeError("OPERATING_MODEL_INVALID")

    projected_steps: list[dict[str, Any]] = []
    for step in steps:
        if not isinstance(step, dict):
            raise RuntimeError("OPERATING_MODEL_INVALID")
        systems = step.get("systems")
        target = step.get("target_response")
        responsible = step.get("responsible")
        if (
            not isinstance(systems, dict)
            or not isinstance(target, dict)
            or not isinstance(responsible, list)
            or not responsible
            or not all(isinstance(role, str) and role for role in responsible)
            or not isinstance(step.get("accountable"), str)
            or not step.get("accountable")
            or systems.get("named_connector_status") != "NOT_RUN"
            or not isinstance(systems.get("as_is_interface_class"), str)
            or not systems.get("as_is_interface_class")
            or target.get("basis") != "DESIGN_TARGET_NOT_OBSERVED_BASELINE"
            or not isinstance(target.get("value"), (int, float))
            or not isinstance(target.get("unit"), str)
        ):
            raise RuntimeError("OPERATING_MODEL_INVALID")
        projected_steps.append(
            {
                "id": step["id"],
                "label": step.get("label"),
                "as_is_interface_class": systems["as_is_interface_class"],
                "named_connector_status": systems["named_connector_status"],
                "responsible": responsible,
                "accountable": step["accountable"],
                "target_response": {
                    "value": target["value"],
                    "unit": target["unit"],
                    "basis": target["basis"],
                },
            }
        )

    return {
        "schema_version": "orgrebase.workspace-operating-model-view.v1",
        "status": "PASS",
        "source": "DECLARED_ENTERPRISE_QUOTE_OPERATING_MODEL",
        "read_model_target_writes": 0,
        "claim_boundary": (
            "DECLARED_REFERENCE_PROCESS_AND_DESIGN_TARGETS_NOT_CURRENT_RUN_RESULTS"
        ),
        "value_and_responsibility": {
            "primary_user": payload["primary_user"],
            "primary_deliverable": payload["primary_deliverable"],
            "process_status": "NOT_RUN",
            "process_steps": projected_steps,
        },
    }


def _default_workspace_store_path() -> str:
    configured = os.environ.get("ORGREBASE_WORKSPACE_DB", "").strip()
    runtime_root = PROJECT_ROOT if (PROJECT_ROOT / "pyproject.toml").is_file() else Path.cwd()
    selected = configured or str(runtime_root / ".orgrebase" / "workspace.sqlite3")
    if selected != ":memory:":
        expanded = Path(selected).expanduser()
        expanded.parent.mkdir(parents=True, exist_ok=True)
        return str(expanded)
    return ":memory:"


def _workspace_review_duration_seconds() -> float:
    raw = os.environ.get("ORGREBASE_WORKSPACE_REVIEW_SECONDS", "4").strip()
    try:
        selected = float(raw or "4")
    except ValueError as exc:
        raise RuntimeError("ORGREBASE_WORKSPACE_REVIEW_SECONDS_INVALID") from exc
    if selected < 4:
        raise RuntimeError("ORGREBASE_WORKSPACE_REVIEW_SECONDS_UNDER_FOUR")
    return selected


def _workspace_approval_identity_mode() -> str:
    return os.environ.get(
        "ORGREBASE_WORKSPACE_IDENTITY_MODE",
        CONTROLLED_LOCAL_HEADER_IDENTITY,
    ).strip()


def _workspace_task_intake_required() -> bool:
    selected = os.environ.get(
        "ORGREBASE_WORKSPACE_TASK_INTAKE_REQUIRED",
        "1",
    ).strip()
    if selected not in {"0", "1"}:
        raise RuntimeError("ORGREBASE_WORKSPACE_TASK_INTAKE_REQUIRED_INVALID")
    return selected == "1"


def _oac_adaptation_review_duration_seconds() -> float:
    raw = os.environ.get("ORGREBASE_OAC_ADAPTATION_REVIEW_SECONDS", "4").strip()
    try:
        selected = float(raw or "4")
    except ValueError as exc:
        raise RuntimeError("ORGREBASE_OAC_ADAPTATION_REVIEW_SECONDS_INVALID") from exc
    if selected < 4:
        raise RuntimeError("ORGREBASE_OAC_ADAPTATION_REVIEW_SECONDS_UNDER_FOUR")
    return selected


def _oac_adaptation_mode() -> str:
    selected = os.environ.get("ORGREBASE_OAC_ADAPTATION_MODE", "optional").strip().lower()
    if selected not in {"off", "optional", "required"}:
        raise RuntimeError("ORGREBASE_OAC_ADAPTATION_MODE_INVALID")
    return selected


def _oac_execution_mode(*, model_provider: str) -> str:
    configured = os.environ.get("ORGREBASE_OAC_EXECUTION_MODE", "").strip()
    if configured:
        selected = configured.upper()
        if selected not in {"FROZEN_REPLAY", "OFFLINE_LOCAL", "LIVE_VERTEX"}:
            raise RuntimeError("ORGREBASE_OAC_EXECUTION_MODE_INVALID")
        return selected
    return "LIVE_VERTEX" if model_provider == "vertex-ai" else "OFFLINE_LOCAL"


def _default_workspace_service() -> WorkspaceService:
    pack_root = os.environ.get("ORGREBASE_ENTERPRISE_PACK", "").strip()
    review_duration_seconds = _workspace_review_duration_seconds()
    approval_identity_mode = _workspace_approval_identity_mode()
    if not pack_root:
        return WorkspaceService(
            store_path=_default_workspace_store_path(),
            review_duration_seconds=review_duration_seconds,
            approval_identity_mode=approval_identity_mode,
            task_intake_required=_workspace_task_intake_required(),
        )
    from orgrebase.workspace.pilot import load_enterprise_quote_pilot_pack

    runtime = load_enterprise_quote_pilot_pack(pack_root)
    return WorkspaceService(
        store_path=_default_workspace_store_path(),
        runtime_configuration=runtime,
        review_duration_seconds=review_duration_seconds,
        approval_identity_mode=approval_identity_mode,
        task_intake_required=_workspace_task_intake_required(),
    )


def _workspace_error(exc: Exception) -> dict[str, Any]:
    detail: dict[str, Any] = {
        "code": str(getattr(exc, "code", str(exc))),
        "message": str(exc),
    }
    remaining_ms = getattr(exc, "remaining_ms", None)
    if isinstance(remaining_ms, int):
        detail["remaining_ms"] = remaining_ms
    not_before = getattr(exc, "not_before", None)
    if isinstance(not_before, str):
        detail["not_before"] = not_before
    return detail


def _workspace_staged_commands_required() -> None:
    raise HTTPException(
        status_code=410,
        detail={
            "code": "WORKSPACE_STAGED_COMMANDS_REQUIRED",
            "message": (
                "one-shot Workspace execution is retired because it cannot represent "
                "an external Runtime Owner decision"
            ),
            "next_endpoints": [
                "POST /api/workspace/task-intake/prepare",
                "POST /api/workspace/task-intake/admit",
                "POST /api/workspace/task-intake/run",
                "POST /api/workspace/preview/{change_kind}",
                "POST /api/workspace/approve/{change_kind}",
                "POST /api/workspace/apply/{change_kind}",
            ],
            "target_writes": 0,
        },
    )


def create_app(
    service: OrgRebaseService | None = None,
    workspace_service: WorkspaceService | None = None,
    oac_agentic_runtime: Any | None = None,
) -> FastAPI:
    runtime = service or OrgRebaseService()
    owns_workspace_runtime = workspace_service is None
    workspace_runtime = workspace_service
    workspace_runtime_lock = Lock()
    oac_adaptation_runtime = None
    oac_adaptation_runtime_lock = Lock()
    oac_agentic_runtime_instance = oac_agentic_runtime
    oac_agentic_runtime_lock = Lock()
    oac_agentic_operation_lock = Lock()
    oac_agentic_tempdir: tempfile.TemporaryDirectory[str] | None = None

    def get_workspace_runtime() -> WorkspaceService:
        nonlocal workspace_runtime
        if workspace_runtime is None:
            with workspace_runtime_lock:
                if workspace_runtime is None:
                    workspace_runtime = _default_workspace_service()
                    application.state.workspace_service = workspace_runtime
                    application.state.workspace_store_path = workspace_runtime.store_path
        return workspace_runtime

    def get_oac_adaptation_runtime():
        """Use the active Workspace store; never create a second control plane."""

        nonlocal oac_adaptation_runtime
        if oac_adaptation_runtime is None:
            with oac_adaptation_runtime_lock:
                if oac_adaptation_runtime is None:
                    from orgrebase.workspace.oac_quote_adaptation import (
                        OACQuoteAdaptationService,
                    )

                    workspace = get_workspace_runtime()
                    oac_root = os.environ.get("ORGREBASE_OAC_ROOT", "").strip() or None
                    kwargs: dict[str, Any] = {
                        "golden_root": _active_golden_evidence_root(),
                    }
                    service_kwargs: dict[str, Any] = {}
                    if _oac_adaptation_mode() == "required":
                        # Required mode gates this exact Workspace run.  Optional
                        # mode is an independent pre-deployment shadow and must
                        # never reuse the frozen/current Golden run identity.
                        service_kwargs["execution_run_id"] = workspace.effective_workflow_run_id
                    oac_adaptation_runtime = OACQuoteAdaptationService(
                        store=workspace.store,
                        profile=workspace.profile,
                        runtime=workspace.runtime_configuration,
                        oac_root=oac_root,
                        review_duration_seconds=_oac_adaptation_review_duration_seconds(),
                        **service_kwargs,
                        **kwargs,
                    )
                    application.state.oac_adaptation_service = oac_adaptation_runtime
        return oac_adaptation_runtime

    def get_oac_agentic_runtime():
        """Join the live mapper, owner gate, context compiler, and shadow proof.

        This coordinator owns no business state.  It reuses the active Workspace
        store and persists only content-addressed, candidate-only evidence next
        to that store (or in an app-scoped temporary directory for in-memory
        tests).
        """

        nonlocal oac_agentic_runtime_instance, oac_agentic_tempdir
        if oac_agentic_runtime_instance is None:
            with oac_agentic_runtime_lock:
                if oac_agentic_runtime_instance is None:
                    from orgrebase.workspace.oac_agentic_runtime import (
                        OACAgenticRuntime,
                    )

                    workspace = get_workspace_runtime()
                    deployment = workspace.runtime_configuration
                    if deployment is None:
                        raise RuntimeError("OAC_AGENTIC_RUNTIME_EXACT_PACK_REQUIRED")
                    configured_root = os.environ.get("ORGREBASE_OAC_AGENTIC_RUNTIME_ROOT", "").strip()
                    if configured_root:
                        runtime_root = Path(configured_root).expanduser().resolve()
                    elif workspace.store_path != ":memory:":
                        runtime_root = (
                            Path(workspace.store_path).expanduser().resolve().parent
                            / "oac-agentic-adaptation"
                        )
                    else:
                        oac_agentic_tempdir = tempfile.TemporaryDirectory(prefix="orgrebase-oac-agentic-")
                        runtime_root = Path(oac_agentic_tempdir.name)
                    checkout = workspace.competition_checkout or Path(
                        os.environ.get(
                            "AGENTTEAMS_CHECKOUT",
                            str(PROJECT_ROOT / ".tmp" / "agentteams-v1.2.2"),
                        )
                    )
                    lock_path = workspace.competition_lock_path or (
                        PROJECT_ROOT / "agentteams" / "teamharness-lock.json"
                    )
                    golden_root = _active_golden_evidence_root()
                    model_provider = workspace.competition_model_provider
                    oac_agentic_runtime_instance = OACAgenticRuntime(
                        runtime_root=runtime_root,
                        repo_root=PROJECT_ROOT,
                        checkout=checkout,
                        lock_path=lock_path,
                        pack_path=deployment.pack_root,
                        frozen_golden_root=golden_root,
                        adaptation_service=get_oac_adaptation_runtime(),
                        workspace_service=workspace,
                        shadow_verifier=(_run_oac_bound_shadow_independent_verifier),
                        shadow_model_provider=model_provider,
                        execution_mode=_oac_execution_mode(
                            model_provider=model_provider,
                        ),
                        vertex_project=workspace.competition_vertex_project,
                        ollama_endpoint=workspace.competition_ollama_endpoint,
                        late_attempt_fencing_receipt=(
                            PROJECT_ROOT
                            / "evidence"
                            / "semifinal-closure"
                            / "latest"
                            / "agentteams"
                            / "lifecycle-receipt.json"
                        ),
                    )
                    application.state.oac_agentic_runtime = oac_agentic_runtime_instance
        return oac_agentic_runtime_instance

    def workspace_oac_gate_view() -> dict[str, Any]:
        """Expose the deploy-time OAC gate without paths or provider secrets."""

        workspace = get_workspace_runtime()
        mode = _oac_adaptation_mode()
        activation = workspace.oac_activation_state()
        required = mode == "required"
        exact_binding_ready = False
        binding_digest = activation.get("activation_binding_digest")
        reason_code = None
        if required:
            deployment = workspace.runtime_configuration
            if deployment is None:
                reason_code = "OAC_ADAPTATION_EXACT_ENTERPRISE_PACK_REQUIRED"
            else:
                try:
                    binding = get_oac_adaptation_runtime().require_activation_binding(
                        profile_digest=workspace.profile_digest,
                        pack_digest=deployment.pack_digest,
                        execution_run_id=workspace.effective_workflow_run_id,
                    )
                except (IntegrityError, RuntimeError, ValueError, KeyError):
                    reason_code = "OAC_ADAPTATION_ACTIVATION_BINDING_REQUIRED"
                else:
                    exact_binding_ready = True
                    binding_digest = binding.digest
        consumed = activation["status"] == "CONSUMED_BY_QUOTE_FORMATION"
        form_allowed = not required or exact_binding_ready
        return {
            "schema_version": "orgrebase.workspace-oac-gate.v1",
            "mode": mode,
            "requires_oac_admission": required,
            "form_allowed": form_allowed,
            "status": (
                "CONSUMED_BY_QUOTE_FORMATION"
                if consumed
                else "READY_TO_FORM"
                if form_allowed
                else "BLOCKED_PENDING_OAC"
            ),
            "execution_run_id": workspace.effective_workflow_run_id,
            "activation_binding_digest": binding_digest,
            "consumption_receipt_digest": activation.get(
                "consumption_receipt_digest"
            ),
            "reason_code": reason_code,
            "canonical_target_writes": 0,
        }

    def with_workspace_oac_gate(view: Any) -> dict[str, Any]:
        result = dict(view)
        result["workspace_gate"] = workspace_oac_gate_view()
        return result

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        try:
            yield
        finally:
            if owns_workspace_runtime and workspace_runtime is not None:
                workspace_runtime.close()
            if oac_agentic_tempdir is not None:
                oac_agentic_tempdir.cleanup()

    application = FastAPI(
        title="OrgRebase",
        version=__version__,
        description="Deterministic enterprise change-consistency runtime",
        lifespan=lifespan,
    )
    application.state.service = runtime
    application.state.workspace_service = workspace_runtime
    application.state.oac_adaptation_service = None
    application.state.oac_agentic_runtime = oac_agentic_runtime_instance
    application.state.workspace_store_path = (
        workspace_runtime.store_path if workspace_runtime is not None else None
    )
    application.mount("/assets", StaticFiles(directory=CONSOLE_DIR), name="assets")

    @application.get("/", include_in_schema=False)
    def console() -> FileResponse:
        return FileResponse(CONSOLE_DIR / "index.html")

    @application.get("/api/health")
    def health() -> dict[str, Any]:
        return {
            "status": "ok",
            "service": "orgrebase",
            "version": __version__,
            "profile": "LOCAL_DETERMINISTIC",
        }

    @application.get("/readyz")
    def readiness() -> dict[str, Any]:
        """Prove that the active Profile, exact sources, and SQLite are usable."""

        workspace = get_workspace_runtime()
        workspace.store.connection.execute("SELECT 1").fetchone()
        runtime = workspace.runtime_configuration
        return {
            "status": "ready",
            "service": "orgrebase",
            "version": __version__,
            "workspace_store": "READY",
            "profile_ref": workspace.profile.ref,
            "profile_digest": workspace.profile_digest,
            "source_admission": workspace.source_admission.verdict,
            "runtime_projection": "MATCH",
            "enterprise_pack_digest": (runtime.pack_digest if runtime is not None else None),
            "deployment_maturity": (workspace.boundaries.get("deployment_maturity", "REFERENCE_RUNTIME")),
            "production_ready": False,
        }

    @application.get("/api/demo/state", include_in_schema=False)
    def state() -> dict[str, Any]:
        return runtime.current_view()

    @application.get("/api/release-facts")
    def release_facts() -> dict[str, Any]:
        if not RELEASE_FACTS_PATH.is_file():
            raise HTTPException(status_code=503, detail="RELEASE_FACTS_UNAVAILABLE")
        value = json.loads(RELEASE_FACTS_PATH.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise HTTPException(status_code=503, detail="RELEASE_FACTS_INVALID")
        return value

    @application.get("/api/platform/evidence")
    @application.get("/api/semifinal/evidence", include_in_schema=False)
    def semifinal_evidence() -> dict[str, Any]:
        from orgrebase.semifinal_view import semifinal_evidence_view

        return semifinal_evidence_view(PROJECT_ROOT)

    @application.get("/api/public-real-process/validation")
    def public_real_process_validation() -> dict[str, Any]:
        from orgrebase.semifinal_view import public_real_process_validation_view

        return public_real_process_validation_view(PROJECT_ROOT)

    @application.get("/api/golden-evidence/status")
    def golden_evidence_status() -> dict[str, Any]:
        workspace = get_workspace_runtime()
        return _golden_evidence_status(
            _active_golden_evidence_root(),
            current_run_id=workspace.effective_workflow_run_id,
        )

    @application.post("/api/demo/reset", include_in_schema=False)
    def reset() -> dict[str, Any]:
        return runtime.reset()

    @application.post("/api/demo/preview", include_in_schema=False)
    def preview() -> dict[str, Any]:
        return runtime.preview()

    @application.post("/api/demo/apply", include_in_schema=False)
    def apply() -> dict[str, Any]:
        try:
            return runtime.apply()
        except FreshnessError as exc:
            raise HTTPException(status_code=409, detail={"code": exc.code, "message": str(exc)}) from exc

    @application.post("/api/demo/run", include_in_schema=False)
    def run() -> dict[str, Any]:
        return runtime.run_demo()

    @application.post("/api/demo/workspace/quote-to-rebase", include_in_schema=False)
    def workspace_quote_to_rebase() -> dict[str, Any]:
        _workspace_staged_commands_required()

    @application.get("/api/demo/workspace/agentteams-status", include_in_schema=False)
    def workspace_agentteams_status() -> dict[str, Any]:
        from orgrebase.workspace.transport import agentteams_status

        return agentteams_status()

    @application.get("/api/workspace/operating-model")
    def workspace_operating_model() -> dict[str, Any]:
        try:
            return _operating_model_view()
        except (RuntimeError, OSError, ValueError, KeyError) as exc:
            raise HTTPException(
                status_code=503,
                detail={
                    "code": "OPERATING_MODEL_UNAVAILABLE",
                    "message": str(exc),
                },
            ) from exc

    @application.get("/api/workspace/skills")
    def workspace_skill_sources() -> dict[str, Any]:
        from orgrebase.workspace.skill_revision import skill_source_catalog

        try:
            return skill_source_catalog(get_workspace_runtime().store)
        except (IntegrityError, RuntimeError, ValueError, KeyError, OSError) as exc:
            raise HTTPException(
                status_code=503,
                detail={
                    "code": "SKILL_SOURCE_CATALOG_UNAVAILABLE",
                    "message": str(exc),
                },
            ) from exc

    @application.post("/api/workspace/skills/{skill_name}/drafts")
    def workspace_skill_revision_draft(
        skill_name: str,
        payload: dict[str, Any],
        x_orgrebase_actor: str | None = Header(
            default=None,
            alias="X-OrgRebase-Actor",
        ),
    ) -> dict[str, Any]:
        from orgrebase.workspace.skill_revision import create_skill_revision_draft

        try:
            workspace = get_workspace_runtime()
            if workspace.approval_identity_mode == CONTROLLED_LOCAL_HEADER_IDENTITY:
                actor_id = (x_orgrebase_actor or "").strip()
                if not actor_id:
                    raise HTTPException(
                        status_code=403,
                        detail={
                            "code": "WORKSPACE_ACTOR_HEADER_REQUIRED",
                            "message": (
                                "X-OrgRebase-Actor is required by the controlled-local identity mode"
                            ),
                            "identity_mode": CONTROLLED_LOCAL_HEADER_IDENTITY,
                            "identity_claim_boundary": (
                                "CONTROLLED_LOCAL_HEADER_IDENTITY_NOT_EXTERNAL_IAM"
                            ),
                            "registry_writes": 0,
                        },
                    )
            else:
                actor_id = str(payload.get("actor_id", "")).strip()
            return create_skill_revision_draft(
                workspace.store,
                name=skill_name,
                actor_id=actor_id,
                source_package_digest=str(payload.get("source_package_digest", "")),
                source_skill_digest=str(payload.get("source_skill_digest", "")),
                proposed_version=str(payload.get("proposed_version", "")),
                content=payload.get("content") if isinstance(payload.get("content"), str) else "",
            )
        except HTTPException:
            raise
        except AuthorizationError as exc:
            raise HTTPException(status_code=403, detail=_workspace_error(exc)) from exc
        except (IntegrityError, RuntimeError, ValueError, KeyError, OSError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.get("/api/workspace/state")
    def workspace_state() -> dict[str, Any]:
        try:
            return get_workspace_runtime().state()
        except (IntegrityError, RuntimeError, ValueError, KeyError, OSError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.get("/api/workspace/experience")
    def workspace_experience() -> dict[str, Any]:
        try:
            return get_workspace_runtime().experience_view()
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(
                status_code=409,
                detail=_workspace_error(exc),
            ) from exc

    @application.post("/api/workspace/experience/{decision}")
    def workspace_experience_decision(
        decision: str,
        payload: dict[str, Any],
        x_orgrebase_actor: str | None = Header(
            default=None,
            alias="X-OrgRebase-Actor",
        ),
    ) -> dict[str, Any]:
        try:
            workspace = get_workspace_runtime()
            if workspace.approval_identity_mode == CONTROLLED_LOCAL_HEADER_IDENTITY:
                actor_id = (x_orgrebase_actor or "").strip()
                if not actor_id:
                    raise HTTPException(
                        status_code=403,
                        detail={
                            "code": "WORKSPACE_ACTOR_HEADER_REQUIRED",
                            "message": (
                                "X-OrgRebase-Actor is required by the controlled-local identity mode"
                            ),
                            "identity_mode": CONTROLLED_LOCAL_HEADER_IDENTITY,
                            "identity_claim_boundary": ("CONTROLLED_LOCAL_HEADER_IDENTITY_NOT_EXTERNAL_IAM"),
                            "target_writes": 0,
                        },
                    )
            else:
                actor_id = str(payload.get("actor_id", ""))
            return workspace.decide_experience(
                run_id=str(payload.get("run_id", "")),
                decision=decision,
                actor_id=actor_id,
                candidate_digest=str(payload.get("candidate_digest", "")),
                evaluation_digest=str(payload.get("evaluation_digest", "")),
                observed_skill_head_digest=str(payload.get("observed_skill_head_digest", "")),
            )
        except HTTPException:
            raise
        except AuthorizationError as exc:
            raise HTTPException(status_code=403, detail=_workspace_error(exc)) from exc
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.get("/api/workspace/profile")
    def workspace_profile() -> dict[str, Any]:
        from orgrebase.workspace.api import workspace_profile_view
        from orgrebase.workspace.profile import northstar_acme_quote_profile

        if workspace_runtime is not None:
            selected = workspace_runtime.profile
        else:
            pack_root = os.environ.get("ORGREBASE_ENTERPRISE_PACK", "").strip()
            if pack_root:
                from orgrebase.workspace.pilot import (
                    load_enterprise_quote_pilot_pack,
                )

                selected = load_enterprise_quote_pilot_pack(pack_root).profile
            else:
                selected = northstar_acme_quote_profile()
        return workspace_profile_view(selected)

    @application.post("/api/workspace/intake")
    def workspace_intake(payload: dict[str, Any]) -> dict[str, Any]:
        from orgrebase.workspace.api import enterprise_intake_view

        try:
            return enterprise_intake_view((payload,))
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=_workspace_error(exc)) from exc

    def task_intake_identity(
        *,
        workspace: WorkspaceService,
        declared_actor_id: str,
        header_actor_id: str | None,
    ) -> str:
        """Resolve the local caller label without treating request text as IAM."""

        if workspace.approval_identity_mode == CONTROLLED_LOCAL_HEADER_IDENTITY:
            actor_id = (header_actor_id or "").strip()
            if not actor_id:
                raise HTTPException(
                    status_code=403,
                    detail={
                        "code": "WORKSPACE_ACTOR_HEADER_REQUIRED",
                        "message": (
                            "X-OrgRebase-Actor is required by the controlled-local identity mode"
                        ),
                        "identity_mode": CONTROLLED_LOCAL_HEADER_IDENTITY,
                        "identity_claim_boundary": (
                            "CONTROLLED_LOCAL_HEADER_IDENTITY_NOT_EXTERNAL_IAM"
                        ),
                        "target_writes": 0,
                    },
                )
        else:
            actor_id = declared_actor_id.strip()
        expected = workspace.profile.default_task.actor_id
        if actor_id != expected:
            raise AuthorizationError(
                f"TASK_INTAKE_ACTOR_DENIED:expected={expected},actual={actor_id}"
            )
        return actor_id

    def task_intake_contract() -> tuple[Any, Any, str | None, bool, str | None]:
        """Resolve the exact Profile/Template/OAC pre-execution boundary."""

        workspace = get_workspace_runtime()
        profile = workspace.profile
        template = workspace.formation.registry.get(profile.default_task.template_ref)
        gate = workspace_oac_gate_view()
        required = bool(gate["requires_oac_admission"])
        binding_digest = (
            str(gate["activation_binding_digest"])
            if required
            and gate["form_allowed"]
            and isinstance(gate.get("activation_binding_digest"), str)
            else None
        )
        reason_code = (
            str(gate["reason_code"])
            if isinstance(gate.get("reason_code"), str)
            else None
        )
        return profile, template, binding_digest, required, reason_code

    @application.post("/api/workspace/task-intake/prepare")
    def workspace_task_intake_prepare(
        payload: dict[str, Any],
        x_orgrebase_actor: str | None = Header(
            default=None,
            alias="X-OrgRebase-Actor",
        ),
    ) -> dict[str, Any]:
        from orgrebase.workspace.task_intake import prepare_task_intake_candidate

        declared_actor = payload.get("actor_id")
        actor_id = declared_actor if isinstance(declared_actor, str) else ""
        try:
            workspace = get_workspace_runtime()
            identity = task_intake_identity(
                workspace=workspace,
                declared_actor_id=actor_id,
                header_actor_id=x_orgrebase_actor,
            )
            profile, template, binding_digest, required, reason_code = (
                task_intake_contract()
            )
            raw_prompt = payload.get("prompt")
            raw_customer = payload.get("customer_id")
            raw_deliverable = payload.get("deliverable_kind")
            candidate = prepare_task_intake_candidate(
                prompt=raw_prompt if isinstance(raw_prompt, str) else "",
                actor_id=identity,
                customer_id=(raw_customer if isinstance(raw_customer, str) else None),
                deliverable_kind=(
                    raw_deliverable if isinstance(raw_deliverable, str) else ""
                ),
                profile=profile,
                template=template,
                intended_run_id=workspace.effective_workflow_run_id,
                workspace_instance_nonce=(
                    workspace.task_intake_workspace_instance_nonce()
                ),
                oac_activation_binding_digest=binding_digest,
                oac_required=required,
                oac_reason_code=reason_code,
            )
            return candidate.model_dump(mode="json")
        except HTTPException:
            raise
        except AuthorizationError as exc:
            raise HTTPException(status_code=403, detail=_workspace_error(exc)) from exc
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.post("/api/workspace/task-intake/admit")
    def workspace_task_intake_admit(
        payload: dict[str, Any],
        x_orgrebase_actor: str | None = Header(
            default=None,
            alias="X-OrgRebase-Actor",
        ),
    ) -> dict[str, Any]:
        from orgrebase.workspace.task_intake import admit_task_intake_candidate

        declared_actor = payload.get("actor_id")
        actor_id = declared_actor if isinstance(declared_actor, str) else ""
        try:
            workspace = get_workspace_runtime()
            identity = task_intake_identity(
                workspace=workspace,
                declared_actor_id=actor_id,
                header_actor_id=x_orgrebase_actor,
            )
            profile, template, binding_digest, required, _ = task_intake_contract()
            candidate_payload = payload.get("candidate_receipt")
            if not isinstance(candidate_payload, dict):
                raise IntegrityError("TASK_INTAKE_CANDIDATE_RECEIPT_REQUIRED")
            candidate_digest = payload.get("candidate_digest")
            approval = admit_task_intake_candidate(
                candidate_payload,
                candidate_digest=(
                    candidate_digest if isinstance(candidate_digest, str) else ""
                ),
                actor_id=identity,
                profile=profile,
                template=template,
                expected_run_id=workspace.effective_workflow_run_id,
                expected_workspace_instance_nonce=(
                    workspace.task_intake_workspace_instance_nonce()
                ),
                expected_oac_activation_binding_digest=binding_digest,
                oac_required=required,
            )
            return approval.model_dump(mode="json")
        except HTTPException:
            raise
        except AuthorizationError as exc:
            raise HTTPException(status_code=403, detail=_workspace_error(exc)) from exc
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.post("/api/workspace/task-intake/run")
    def workspace_task_intake_run(
        payload: dict[str, Any],
        x_orgrebase_actor: str | None = Header(
            default=None,
            alias="X-OrgRebase-Actor",
        ),
    ) -> dict[str, Any]:
        from orgrebase.workspace.task_intake import (
            validate_task_intake_work_description,
            verify_task_intake_approval,
            verify_task_intake_candidate,
        )

        declared_actor = payload.get("actor_id")
        actor_id = declared_actor if isinstance(declared_actor, str) else ""
        try:
            workspace = get_workspace_runtime()
            identity = task_intake_identity(
                workspace=workspace,
                declared_actor_id=actor_id,
                header_actor_id=x_orgrebase_actor,
            )
            profile, template, binding_digest, required, _ = task_intake_contract()
            candidate_payload = payload.get("candidate_receipt")
            approval_payload = payload.get("approval_receipt")
            if not isinstance(candidate_payload, dict):
                raise IntegrityError("TASK_INTAKE_CANDIDATE_RECEIPT_REQUIRED")
            if not isinstance(approval_payload, dict):
                raise IntegrityError("TASK_INTAKE_APPROVAL_RECEIPT_REQUIRED")
            candidate = verify_task_intake_candidate(
                candidate_payload,
                profile=profile,
                template=template,
                expected_run_id=workspace.effective_workflow_run_id,
                expected_workspace_instance_nonce=(
                    workspace.task_intake_workspace_instance_nonce()
                ),
                expected_oac_activation_binding_digest=binding_digest,
                oac_required=required,
            )
            work_description = validate_task_intake_work_description(
                payload.get("work_description")
            )
            if (
                sha256_digest(work_description) != candidate.prompt_digest
                or len(work_description) != candidate.prompt_length
            ):
                raise IntegrityError("TASK_INTAKE_WORK_DESCRIPTION_MISMATCH")
            candidate_digest = payload.get("candidate_digest")
            if not isinstance(candidate_digest, str) or candidate_digest != candidate.digest:
                raise IntegrityError("TASK_INTAKE_CANDIDATE_DIGEST_MISMATCH")
            approval = verify_task_intake_approval(
                approval_payload,
                candidate=candidate,
                actor_id=identity,
                profile=profile,
                template=template,
                expected_run_id=workspace.effective_workflow_run_id,
                expected_workspace_instance_nonce=(
                    workspace.task_intake_workspace_instance_nonce()
                ),
                expected_oac_activation_binding_digest=binding_digest,
                oac_required=required,
            )
            approval_digest = payload.get("approval_digest")
            if not isinstance(approval_digest, str) or approval_digest != approval.digest:
                raise IntegrityError("TASK_INTAKE_APPROVAL_DIGEST_MISMATCH")

            activation_binding_payload = None
            formation_decision_payload = None
            context_envelope_payload = None
            if required:
                deployment = workspace.runtime_configuration
                if deployment is None:
                    raise IntegrityError("OAC_ADAPTATION_EXACT_ENTERPRISE_PACK_REQUIRED")
                with oac_agentic_operation_lock:
                    binding = get_oac_adaptation_runtime().require_activation_binding(
                        profile_digest=workspace.profile_digest,
                        pack_digest=deployment.pack_digest,
                        execution_run_id=workspace.effective_workflow_run_id,
                    )
                    if binding.digest != binding_digest:
                        raise IntegrityError("TASK_INTAKE_OAC_BINDING_CHANGED")
                    formation_decision, context_envelope = (
                        get_oac_agentic_runtime().formation_roots_for_current_task(
                            expected_activation_binding_digest=binding.digest,
                        )
                    )
                activation_binding_payload = binding.model_dump(mode="json")
                formation_decision_payload = formation_decision.model_dump(mode="json")
                context_envelope_payload = context_envelope.model_dump(mode="json")

            result = workspace.form_quote_with_dependency_evidence(
                candidate.task_request,
                oac_activation_binding=activation_binding_payload,
                task_formation_decision_receipt=formation_decision_payload,
                context_envelope=context_envelope_payload,
                task_intake_candidate=candidate.model_dump(mode="json"),
                task_intake_approval=approval.model_dump(mode="json"),
                task_intake_work_description=work_description,
            )
            if result.get("task_intake") is None:
                raise IntegrityError("WORKSPACE_TASK_INTAKE_PERSISTENCE_MISSING")
            return result
        except HTTPException:
            raise
        except AuthorizationError as exc:
            raise HTTPException(status_code=403, detail=_workspace_error(exc)) from exc
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.get("/api/workspace/task-intake/work-description")
    def workspace_task_intake_work_description(
        x_orgrebase_actor: str | None = Header(
            default=None,
            alias="X-OrgRebase-Actor",
        ),
    ) -> dict[str, Any]:
        """Read private task text for the exact current task actor only."""

        try:
            workspace = get_workspace_runtime()
            declared_actor = (x_orgrebase_actor or "").strip()
            if not declared_actor:
                raise HTTPException(
                    status_code=403,
                    detail={
                        "code": "WORKSPACE_ACTOR_HEADER_REQUIRED",
                        "message": "X-OrgRebase-Actor is required for private task text",
                        "target_writes": 0,
                    },
                )
            identity = task_intake_identity(
                workspace=workspace,
                declared_actor_id=declared_actor,
                header_actor_id=x_orgrebase_actor,
            )
            record = workspace.task_intake_work_description(actor_id=identity)
            if record is None:
                raise HTTPException(
                    status_code=404,
                    detail={
                        "code": "TASK_INTAKE_WORK_DESCRIPTION_NOT_RETAINED",
                        "message": (
                            "This run has no retained private work description; "
                            "the server will not reconstruct one from a digest"
                        ),
                        "target_writes": 0,
                    },
                )
            return record
        except HTTPException:
            raise
        except AuthorizationError as exc:
            raise HTTPException(status_code=403, detail=_workspace_error(exc)) from exc
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.get("/api/workspace/oac-adaptation")
    def workspace_oac_adaptation() -> dict[str, Any]:
        if _oac_adaptation_mode() == "off":
            raise HTTPException(
                status_code=503,
                detail={
                    "code": "OAC_ADAPTATION_DISABLED",
                    "message": "OAC enterprise adaptation is disabled for this deployment",
                    "canonical_target_writes": 0,
                },
            )
        try:
            return get_oac_adaptation_runtime().view()
        except (IntegrityError, RuntimeError, ValueError, KeyError, OSError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.get("/api/workspace/oac-adaptation/agentic")
    def workspace_oac_agentic_adaptation() -> dict[str, Any]:
        if _oac_adaptation_mode() == "off":
            raise HTTPException(
                status_code=503,
                detail={"code": "OAC_ADAPTATION_DISABLED"},
            )
        try:
            with oac_agentic_operation_lock:
                return with_workspace_oac_gate(get_oac_agentic_runtime().view())
        except (IntegrityError, RuntimeError, ValueError, KeyError, OSError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.post("/api/workspace/oac-adaptation/agent-prepare")
    def workspace_oac_agentic_prepare(payload: dict[str, Any]) -> dict[str, Any]:
        if _oac_adaptation_mode() == "off":
            raise HTTPException(
                status_code=503,
                detail={"code": "OAC_ADAPTATION_DISABLED"},
            )
        try:
            with oac_agentic_operation_lock:
                return with_workspace_oac_gate(
                    get_oac_agentic_runtime().agent_prepare(
                        command_id=str(payload.get("command_id", "")),
                    )
                )
        except (IntegrityError, RuntimeError, ValueError, KeyError, OSError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.post("/api/workspace/oac-adaptation/execute-shadow")
    def workspace_oac_agentic_execute_shadow() -> dict[str, Any]:
        if _oac_adaptation_mode() == "off":
            raise HTTPException(
                status_code=503,
                detail={"code": "OAC_ADAPTATION_DISABLED"},
            )
        try:
            with oac_agentic_operation_lock:
                return with_workspace_oac_gate(
                    get_oac_agentic_runtime().execute_shadow()
                )
        except (IntegrityError, RuntimeError, ValueError, KeyError, OSError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.post("/api/workspace/oac-adaptation/prepare")
    def workspace_oac_adaptation_prepare(payload: dict[str, Any]) -> dict[str, Any]:
        if _oac_adaptation_mode() == "off":
            raise HTTPException(status_code=503, detail={"code": "OAC_ADAPTATION_DISABLED"})
        try:
            with oac_agentic_operation_lock:
                return get_oac_adaptation_runtime().prepare(
                    command_id=str(payload.get("command_id", "")),
                )
        except (IntegrityError, RuntimeError, ValueError, KeyError, OSError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.post("/api/workspace/oac-adaptation/approve")
    def workspace_oac_adaptation_approve(
        payload: dict[str, Any],
        x_orgrebase_actor: str | None = Header(
            default=None,
            alias="X-OrgRebase-Actor",
        ),
    ) -> dict[str, Any]:
        if _oac_adaptation_mode() == "off":
            raise HTTPException(status_code=503, detail={"code": "OAC_ADAPTATION_DISABLED"})
        try:
            workspace = get_workspace_runtime()
            if workspace.approval_identity_mode == CONTROLLED_LOCAL_HEADER_IDENTITY:
                actor_id = (x_orgrebase_actor or "").strip()
                if not actor_id:
                    raise HTTPException(
                        status_code=403,
                        detail={
                            "code": "WORKSPACE_ACTOR_HEADER_REQUIRED",
                            "message": "X-OrgRebase-Actor is required by controlled-local identity mode",
                            "canonical_target_writes": 0,
                        },
                    )
            else:
                actor_id = str(payload.get("actor_id", "")).strip()
            with oac_agentic_operation_lock:
                return get_oac_adaptation_runtime().approve(
                    actor_id=actor_id,
                    candidate_digest=str(payload.get("candidate_digest", "")),
                    command_id=str(payload.get("command_id", "")),
                    owner_review_summary_digest=str(
                        payload.get("owner_review_summary_digest", "")
                    ),
                    acknowledgements=(
                        tuple(str(item) for item in payload["acknowledgements"])
                        if isinstance(payload.get("acknowledgements"), list)
                        else ()
                    ),
                )
        except HTTPException:
            raise
        except AuthorizationError as exc:
            raise HTTPException(status_code=403, detail=_workspace_error(exc)) from exc
        except (IntegrityError, RuntimeError, ValueError, KeyError, OSError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.post("/api/workspace/form")
    def workspace_form(payload: dict[str, Any] | None = None) -> dict[str, Any]:
        from orgrebase.workspace.models import TaskRequest

        try:
            request = TaskRequest.model_validate(payload) if payload else None
            workspace = get_workspace_runtime()
            if workspace.task_intake_required:
                raise HTTPException(
                    status_code=410,
                    detail={
                        "code": "WORKSPACE_TASK_INTAKE_REQUIRED",
                        "message": (
                            "Direct Quote formation is retired for this product runtime; "
                            "submit, confirm, and run an employee task intake instead"
                        ),
                        "next_endpoints": [
                            "POST /api/workspace/task-intake/prepare",
                            "POST /api/workspace/task-intake/admit",
                            "POST /api/workspace/task-intake/run",
                        ],
                        "canonical_target_writes": 0,
                    },
                )
            activation_binding = None
            formation_decision_payload = None
            context_envelope_payload = None
            if _oac_adaptation_mode() == "required":
                deployment = workspace.runtime_configuration
                if deployment is None:
                    raise RuntimeError("OAC_ADAPTATION_EXACT_ENTERPRISE_PACK_REQUIRED")
                with oac_agentic_operation_lock:
                    activation_binding = (
                        get_oac_adaptation_runtime().require_activation_binding(
                            profile_digest=workspace.profile_digest,
                            pack_digest=deployment.pack_digest,
                            execution_run_id=workspace.effective_workflow_run_id,
                        )
                    )
                    formation_decision, context_envelope = (
                        get_oac_agentic_runtime().formation_roots_for_current_task(
                            expected_activation_binding_digest=activation_binding.digest,
                        )
                    )
                formation_decision_payload = formation_decision.model_dump(mode="json")
                context_envelope_payload = context_envelope.model_dump(mode="json")
            return workspace.form_quote_with_dependency_evidence(
                request,
                oac_activation_binding=(
                    activation_binding.model_dump(mode="json")
                    if activation_binding is not None
                    else None
                ),
                task_formation_decision_receipt=formation_decision_payload,
                context_envelope=context_envelope_payload,
            )
        except HTTPException:
            raise
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(
                status_code=409,
                detail=_workspace_error(exc),
            ) from exc

    @application.post("/api/workspace/preview/{change_kind}")
    def workspace_preview(change_kind: str) -> dict[str, Any]:
        try:
            return get_workspace_runtime().preview_command(change_kind)
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(
                status_code=409,
                detail=_workspace_error(exc),
            ) from exc

    @application.post("/api/workspace/approve/{change_kind}")
    def workspace_approve(
        change_kind: str,
        payload: dict[str, Any],
        x_orgrebase_actor: str | None = Header(
            default=None,
            alias="X-OrgRebase-Actor",
        ),
    ) -> dict[str, Any]:
        try:
            workspace = get_workspace_runtime()
            if workspace.approval_identity_mode == CONTROLLED_LOCAL_HEADER_IDENTITY:
                actor_id = (x_orgrebase_actor or "").strip()
                if not actor_id:
                    raise HTTPException(
                        status_code=403,
                        detail={
                            "code": "WORKSPACE_ACTOR_HEADER_REQUIRED",
                            "message": (
                                "X-OrgRebase-Actor is required by the controlled-local identity mode"
                            ),
                            "identity_mode": CONTROLLED_LOCAL_HEADER_IDENTITY,
                            "identity_claim_boundary": ("CONTROLLED_LOCAL_HEADER_IDENTITY_NOT_EXTERNAL_IAM"),
                            "target_writes": 0,
                        },
                    )
            else:
                actor_id = str(payload.get("actor_id", ""))
            return workspace.approve_change(
                change_kind,
                actor_id=actor_id,
                preview_digest=str(payload.get("preview_digest", "")),
            )
        except HTTPException:
            raise
        except AuthorizationError as exc:
            raise HTTPException(status_code=403, detail=_workspace_error(exc)) from exc
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.post("/api/workspace/apply/{change_kind}")
    def workspace_apply(change_kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            return get_workspace_runtime().apply_approved_change(
                change_kind,
                approval_digest=str(payload.get("approval_digest", "")),
            )
        except AuthorizationError as exc:
            raise HTTPException(status_code=403, detail=_workspace_error(exc)) from exc
        except (FreshnessError, IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.post("/api/workspace/reset")
    def workspace_reset() -> dict[str, Any]:
        if os.environ.get("ORGREBASE_ALLOW_DESTRUCTIVE_RESET", "").strip() != "1":
            raise HTTPException(
                status_code=403,
                detail={
                    "code": "WORKSPACE_DESTRUCTIVE_RESET_DISABLED",
                    "message": (
                        "workspace reset is a maintenance-only destructive operation; "
                        "set ORGREBASE_ALLOW_DESTRUCTIVE_RESET=1 explicitly"
                    ),
                    "target_writes": 0,
                },
            )
        try:
            return get_workspace_runtime().reset()
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc

    @application.get("/api/workspace/export/quote")
    def workspace_export_quote() -> JSONResponse:
        try:
            payload = get_workspace_runtime().export_quote()
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc
        return JSONResponse(
            content=jsonable_encoder(payload),
            headers={"Content-Disposition": 'attachment; filename="orgrebase-quote.json"'},
        )

    @application.get("/api/workspace/export/evidence")
    def workspace_export_evidence() -> JSONResponse:
        try:
            payload = get_workspace_runtime().export_evidence()
        except (IntegrityError, RuntimeError, ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=_workspace_error(exc)) from exc
        return JSONResponse(
            content=jsonable_encoder(payload),
            headers={"Content-Disposition": 'attachment; filename="orgrebase-evidence.json"'},
        )

    @application.post("/api/workspace/run")
    def workspace_run() -> dict[str, Any]:
        _workspace_staged_commands_required()

    @application.post("/api/demo/conflict", include_in_schema=False)
    def conflict_drill() -> dict[str, Any]:
        return runtime.conflict_drill()

    @application.post("/api/demo/failure", include_in_schema=False)
    def failure_drill() -> dict[str, Any]:
        return runtime.freshness_failure_drill()

    @application.post("/api/demo/rollback", include_in_schema=False)
    def rollback() -> dict[str, Any]:
        try:
            return runtime.rollback()
        except FreshnessError as exc:
            raise HTTPException(status_code=409, detail={"code": exc.code, "message": str(exc)}) from exc

    @application.get("/api/demo/observability", include_in_schema=False)
    def observability() -> dict[str, Any]:
        return runtime.observability()

    @application.get("/api/tools/v1/dependency-evidence/contract")
    def dependency_tool_contract() -> dict[str, Any]:
        return runtime.tool_contract()

    @application.get("/api/tools/v1/git-artifact/contract")
    def git_tool_contract() -> dict[str, Any]:
        return runtime.git_tool_contract()

    @application.post("/api/tools/v1/dependency-evidence")
    def dependency_tool(
        payload: dict[str, Any],
        x_orgrebase_actor: str = Header(alias="X-OrgRebase-Actor"),
    ) -> dict[str, Any]:
        raw_targets = payload.get("target_ids", ())
        if not isinstance(raw_targets, list):
            raise HTTPException(status_code=400, detail="INVALID_TARGET")
        try:
            return runtime.invoke_dependency_tool(
                actor_id=x_orgrebase_actor,
                target_ids=tuple(raw_targets),
                graph_revision=str(payload.get("graph_revision", "")),
                idempotency_key=str(payload.get("idempotency_key", "")),
            )
        except AuthorizationError as exc:
            raise HTTPException(status_code=403, detail={"code": exc.code, "message": str(exc)}) from exc
        except (RuntimeError, ValueError) as exc:
            raise HTTPException(status_code=409, detail={"code": str(exc), "message": str(exc)}) from exc

    @application.get("/api/demo/no-semantic-delta", include_in_schema=False)
    def no_semantic_delta() -> dict[str, Any]:
        return runtime.no_semantic_delta()

    @application.post("/api/receipts/verify")
    def verify_receipt(payload: dict[str, Any]) -> dict[str, Any]:
        try:
            return runtime.verify_receipt(payload)
        except IntegrityError as exc:
            raise HTTPException(status_code=422, detail={"code": exc.code, "message": str(exc)}) from exc

    @application.post("/api/impact-certificates/verify")
    def verify_impact_certificate(payload: dict[str, Any]) -> dict[str, Any]:
        try:
            return runtime.verify_impact_certificate(payload)
        except IntegrityError as exc:
            raise HTTPException(
                status_code=422,
                detail={"code": exc.code, "message": str(exc)},
            ) from exc

    @application.post("/api/minimal-rebase-certificates/verify")
    def verify_minimal_rebase_certificate(payload: dict[str, Any]) -> dict[str, Any]:
        try:
            return runtime.verify_minimal_rebase_certificate(payload)
        except IntegrityError as exc:
            raise HTTPException(
                status_code=422,
                detail={"code": exc.code, "message": str(exc)},
            ) from exc

    @application.post("/api/receipts/rollback/verify")
    def verify_rollback_receipt(payload: dict[str, Any]) -> dict[str, Any]:
        try:
            return runtime.verify_rollback_receipt(payload)
        except IntegrityError as exc:
            raise HTTPException(status_code=422, detail={"code": exc.code, "message": str(exc)}) from exc

    return application


app = create_app()
