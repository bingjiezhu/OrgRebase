---
name: enterprise-quote-compose
description: Execute the exact evaluated quote-composition candidate as a side-effect-free controlled release artifact.
version: 1.2.0
contract: contract.json
---

# Enterprise Quote Compose

Use this package only for the exact hardened declarative program bound by
`package.json`. Version 1.2 adds field-driven fail-closed security gates before
the functional mapping.
The historical `SkillCandidateArtifact` remains `executable=false`; this package is
a separate release artifact authorized by the Skill Registry Authority.

## Required behavior

1. Require `skill_partition`, `candidate_program_digest_required`, and non-zero
   `dependency_tool_receipt_digest` / `dependency_result_digest` bindings.
2. Reject a caller whose requested program digest is not the exact packaged
   program content digest.
3. Execute only `REQUIRE_FIELDS`, `MAP_VALUE`, and `RETURN_FIELD` operations.
4. Return a candidate-only result with `target_writes=0`.
5. Deny permission expansion, safely abstain on injection, malformed input, or
   resource/deadline failure.

## Claim boundary

This controlled adapter proves exact packaging, loading, restricted invocation,
evaluation, and release wiring. It does not prove that the system learned a Skill
from employee behavior or that the mapping generalizes to a new enterprise.
