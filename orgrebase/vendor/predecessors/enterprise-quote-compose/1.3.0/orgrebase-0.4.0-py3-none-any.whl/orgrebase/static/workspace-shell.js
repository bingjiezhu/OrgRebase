(() => {
  "use strict";

  const ROUTES = Object.freeze([
    { id: "overview", icon: "⌂", order: "01", lifecycle: "daily", section: "daily" },
    { id: "quote", icon: "◆", order: "02", lifecycle: "daily", section: "daily" },
    { id: "data", icon: "↗", order: "03", lifecycle: "daily", section: "daily" },
    { id: "agents", icon: "⌘", order: "04", lifecycle: "daily", section: "daily" },
    { id: "acceptance", icon: "✓", order: "05", lifecycle: "daily", section: "daily" },
    { id: "materials", icon: "▤", order: "06", lifecycle: "onboarding", section: "onboarding" },
    { id: "oac", icon: "◎", order: "07", lifecycle: "onboarding", section: "onboarding" },
    { id: "skills", icon: "◇", order: "08", lifecycle: "daily", section: "daily-assurance" },
    { id: "validation", icon: "⌁", order: "09", lifecycle: "daily", section: "daily-assurance" },
    { id: "operations", icon: "◉", order: "10", lifecycle: "daily", section: "daily-assurance" },
  ]);
  const ROUTE_ALIASES = Object.freeze({
    "enterprise-input": "materials",
    "data-evolution": "data",
    value: "acceptance",
  });
  const STAGES = Object.freeze([
    "EMPTY",
    "QUOTE_V1",
    "LAUNCH_PREVIEWED",
    "LAUNCH_APPROVED",
    "QUOTE_V2",
    "CURRENCY_PREVIEWED",
    "CURRENCY_APPROVED",
    "QUOTE_V3",
  ]);
  const COMPONENTS = Object.freeze(["DOMAIN", "KNOWLEDGE", "AUTHORITY", "CAPABILITY", "DEPENDENCY"]);

  const COPY = Object.freeze({
    "zh-CN": Object.freeze({
      product: "企业工作平台",
      workspaceLabel: "当前工作事项",
      workspaceName: "蓝港客户企业报价",
      workspaceType: "企业报价 · 受控本地",
      environment: "受控验证环境",
      operator: "企业报价专员",
      lifecycleOnboarding: "企业接入",
      lifecycleOnboardingDetail: "低频 · 首次接入或契约变更",
      lifecycleDaily: "企业日常工作",
      lifecycleDailyDetail: "高频 · 员工发起与完成任务",
      navigation: "一次接入 · 持续工作",
      workspaceNavigationAria: "OrgRebase 工作区导航",
      lifecycleNavigationAria: "工作区生命周期",
      sectionDaily: "日常工作",
      sectionDailyAssurance: "日常治理与保障",
      sectionOnboarding: "企业接入",
      pages: {
        overview: ["总览", "先看清当前处于接入还是工作阶段", "企业只接入一次；之后员工从工作事项发起受 OAC 约束的日常任务。"],
        quote: ["工作事项", "由员工发起一项工作", "当前已验证任务类型是企业报价：先确认需求，再由动态 Agent 团队生成内部工作稿，并完成两次可追溯的选择性变更。"],
        data: ["业务数据演化", "看见一次任务的数据如何变化", "从员工需求、最小上下文到协作工作稿、上线日期确认稿与币种确认稿，逐项解释重建、保留与匹配负责人的变更批准。"],
        agents: ["Agent 协作", "看见每个 Agent 做了什么", "展示本次实际任务拓扑、上下文交接，以及每个 Agent 调用的 Tool/Skill、审查与候选验收。"],
        acceptance: ["任务验收", "验收当前业务任务", "只汇总本次运行已经产生并校验的责任链、终态回执与选择性 Rebase 结果，不借用独立测试档案。"],
        materials: ["接入数据", "企业第一次接入时提供什么", "展示长期企业材料如何进入安全投影；本次员工任务不混入接入数据。"],
        oac: ["OAC 组织契约", "把企业材料编译成长期运行契约", "接入 Agent 生成候选；指定负责人审阅准入，控制面保留最终权威。"],
        skills: ["能力中心", "管理 Agent 可使用和可演进的能力", "查看当前调用、已发布 Skill、评测与回滚边界，并对运行产生的经验候选做人工发布决策。"],
        validation: ["独立机制验证", "动态组队与控制语义", "本页只证明按需组队、权威边界、冲突隔离和公开真实流程上的范围收缩；它与当前业务运行分离，不表示报价任务又执行了一次。"],
        operations: ["运行保障", "企业运行所需的工程证据", "集中查看 OTLP、告警、留存、容量、恢复、部署、SBOM 与生产验证边界。"],
      },
      navState: { done: "已完成", current: "当前", ready: "可进入", waiting: "待进入", audit: "可审计", loading: "读取中", unavailable: "不可用" },
      pageKicker: "OrgRebase 企业工作区",
      currentStage: "当前阶段",
      currentRun: "当前运行",
      onboardingContext: "接入状态",
      onboardingIdentity: "契约激活身份",
      dailyAssuranceContext: "日常治理",
      dailyAssuranceIdentity: "与当前任务的关系",
      currentOrganization: "当前组织",
      onboardingWorkspaceType: "OAC 企业接入 · 受控试点",
      dailyAssuranceWorkspaceType: "企业日常工作 · 治理与保障",
      dailyAssuranceFacts: {
        skills: ["能力治理", "当前调用 + 跨运行人工发布"],
        validation: ["独立机制证据", "不重复执行当前报价任务"],
        operations: ["工程运行证据", "当前运行 + 独立保障档案"],
      },
      onboardingPending: "等待 OAC 准入",
      onboardingReady: "组织契约已激活",
      onboardingConsumed: "组织契约已在任务中使用",
      onboardingIdentityPending: "等待激活摘要",
      onboardingIdentityBound: "已绑定当前组织与工作区",
      workspaceLoading: "正在读取权威状态",
      workspaceUnavailable: "工作区状态不可用",
      overviewProblem: "原本的问题",
      overviewProblemValue: "一次报价变化要跨越产品、法务、财务、市场与商业化，以及多套系统",
      overviewSolution: "OrgRebase 的处理",
      overviewSolutionValue: "OAC 先固定企业输入、权威与准入边界；业务任务形成时再编译最小 Agent 团队与上下文",
      overviewResult: "最终结果",
      overviewResultValue: "人工负责人只在高风险节点点击，控制面选择性写入并保留完整证据",
      overviewFlowOnboarding: ["企业材料", "候选映射", "人工准入", "组织契约激活"],
      overviewFlowDaily: ["员工需求", "受约束任务", "动态组队", "协作工作稿", "两轮选择性 Rebase", "币种确认稿"],
      openMaterials: "继续企业接入",
      openOac: "继续组织契约适配",
      viewActiveOac: "查看已激活组织契约",
      openWorkItem: "发起工作需求",
      continueWorkItem: "继续当前工作事项",
      viewCompletedWork: "查看已完成工作事项",
      materialsKicker: "企业材料成熟度 · 等待服务端证据",
      materialsTitle: "企业提供五类长期材料，系统编译为组织契约",
      materialsBody: "浏览器只读取后端已准入的安全投影；材料是受控合成样例还是其他数据类型，严格依据服务端数据分类与合成标记展示。本次员工任务与原始私密值均不混入接入材料。",
      materialClassSynthetic: "受控合成企业样例 · 仅验证结构闭环",
      materialClassObserved: "服务端已声明数据类型：{dataClass}",
      materialClassUnclassified: "数据类型未观测 · 不推断材料成熟度",
      materialClassUnavailable: "材料状态不可用 · 不展示为已加载",
      materialStatusReady: "来源已准入并与运行配置匹配",
      materialStatusWaiting: "等待安全输入投影",
      pack: "企业材料包",
      organization: "接入组织",
      profile: "组织配置",
      actor: "任务发起人",
      customer: "目标客户",
      purpose: "任务目的",
      deliverable: "预期交付物",
      template: "输出模板",
      fiveRoots: "五类 OAC 根材料",
      facts: "已准入组织事实",
      factsCount: "{count} 项当前会话可见的安全投影字段",
      rootCount: "{count}/5 类材料已装载",
      inputToOutput: "从企业输入到可执行工作区",
      flowSource: "企业材料",
      flowSourceDetail: "事实、来源、权威、敏感级别",
      flowOac: "OAC 契约",
      flowOacDetail: "领域、知识、权限、能力、依赖",
      flowContext: "人工准入",
      flowContextDetail: "精确摘要、未知项与指定负责人",
      flowOutcome: "组织契约激活",
      flowOutcomeDetail: "后续任务持续受权限、能力和上下文边界约束",
      loadedByConfig: "由启动配置安全装载",
      exactVersionBound: "已绑定精确版本",
      materialPackName: "当前企业材料包",
      materialOrganizationName: "当前接入组织",
      componentComplete: "完整",
      componentSource: "{component}材料来源",
      sourceRegistered: "{domain}数据源已登记",
      authorityMatched: "{domain}权威负责人已匹配",
      domainNames: { product: "产品", legal: "法务", finance: "财务", gtm: "市场与商业化" },
      noSource: "当前服务尚未返回企业材料安全投影；页面不会补造输入。",
      noValue: "未提供",
      source: "来源",
      authority: "权威",
      sensitivity: "敏感级别",
      completeness: "完整性",
      digest: "摘要",
      componentNames: { DOMAIN: "领域", KNOWLEDGE: "知识", AUTHORITY: "权威", CAPABILITY: "能力", DEPENDENCY: "依赖" },
      slotNames: {
        product_plan: "企业方案", launch_date: "上线日期", data_residency: "数据驻留",
        notice_required: "客户通知要求", price_band: "价格带", currency: "报价币种",
        partner_terms: "合作条款", quote_compose_skill: "报价组装 Skill", public_message: "对外口径",
      },
      sensitivityNames: { PUBLIC: "公开", INTERNAL: "内部", CONFIDENTIAL: "机密", RESTRICTED: "受限" },
      materialValueNames: {
        USD: "美元（USD）",
        "US and EU regions supported": "支持美国与欧盟区域驻留",
        "legal-review": "需要法务复核",
        strategic: "战略客户定价",
        "Evergreen Enterprise Plus": "常青企业增强版",
        "The enterprise launch remains on the approved schedule.": "企业版上线计划仍按已批准时间执行",
        "skill:enterprise-quote-compose@1.0": "企业报价组装 Skill",
      },
      materialPackNames: { "pack:evergreen-enterprise-quote@r1": "常青工业企业报价接入包" },
      organizationNames: { "org:evergreen-industries": "常青工业" },
      customerNames: { "customer:blue-harbor": "蓝港客户" },
      routeUnavailable: "页面不可用",
      routeUnavailableBody: "对应产品组件没有加载；已停止展示，不补造数据。",
      routeNext: "下一页",
      stageNames: {
        EMPTY: "等待员工提出需求", QUOTE_V1: "内部工作稿已形成", LAUNCH_PREVIEWED: "产品日期变更待审批", LAUNCH_APPROVED: "产品日期变更已批准 · 待应用",
        QUOTE_V2: "产品日期变更已应用", CURRENCY_PREVIEWED: "币种变更待审批", CURRENCY_APPROVED: "币种变更已批准 · 待应用", QUOTE_V3: "内部变更闭环已校验",
      },
      runPending: "业务运行待形成",
      runAwaitingEmployee: "等待员工发起工作",
      runCandidatePending: "员工确认后启动业务运行",
      runActive: "业务运行进行中",
      runComplete: "内部变更闭环已校验",
      taskCandidateStage: "需求候选待确认",
      caseBadge: "当前事项",
      taskIntakeKicker: "服务端任务入口 · 当前验证类型：企业报价",
      taskIntakeTitle: "先说明本次工作目标，再校验并形成受约束任务候选",
      taskIntakeBody: "工作说明用于确认员工正在请求当前已准入的“企业报价”任务；无关请求会进入人工处理队列。客户、交付物、事实和权限仍只来自已准入契约，不从 Prompt 中提取或扩大。",
      taskCompletedKicker: "员工发起记录 · 已绑定当前运行",
      taskCompletedTitle: "员工需求已确认",
      taskCompletedBody: "本次工作说明已经校验并启动 Agent 团队；客户、事实与权限始终来自已准入组织契约。",
      taskPromptLabel: "本次工作说明",
      taskPromptExample: "请为蓝港客户生成一份符合现行产品、法务、财务、市场与商业化规则的企业报价。",
      taskPrivateTitle: "员工提交的工作说明",
      taskPrivateScope: "仅当前任务发起人可见 · 不进入公开证据、事件或观测数据",
      taskPrivateLoading: "正在读取本次任务的私有工作说明……",
      taskPrivateNotRetained: "该运行没有保留可验证的员工工作说明原文；系统不会根据摘要补造。",
      taskPrivateUnavailable: "当前无法读取私有工作说明；已停止展示，不使用摘要替代原文。",
      taskActorLabel: "发起人",
      taskCustomerLabel: "客户",
      taskKindLabel: "当前任务类型",
      taskKindValue: "企业报价",
      taskContractLabel: "组织契约",
      taskContractReady: "已就绪 · 启动时由服务端校验",
      taskContractBlocked: "企业接入尚未完成",
      taskCompleteOnboarding: "先完成企业接入",
      taskPrepare: "校验工作说明并生成候选",
      taskPreparing: "正在校验并生成受约束候选…",
      taskAdmit: "确认范围并准入任务",
      taskAdmitting: "正在绑定员工确认…",
      taskAdmittedButton: "任务已准入",
      taskRun: "启动 Agent 团队",
      taskRunning: "正在启动 Agent 团队…",
      taskCandidateTitle: "受约束任务候选",
      taskCandidateReady: "等待员工确认",
      taskCandidateHold: "已停在人工处理队列",
      taskTemplateLabel: "采用模板",
      taskTemplateValue: "企业报价标准模板",
      taskDigestLabel: "启动证据",
      taskChainProof: "员工候选已确认 · 组织契约已校验 · Agent 团队已启动",
      taskCandidateProof: "候选已生成 · 等待员工确认",
      taskHoldProof: "工作意图校验未通过 · 未启动 Agent 团队",
      taskAdmittedProof: "员工确认已绑定 · 等待启动 Agent 团队",
      taskAdmittedRetryProof: "员工确认已绑定 · 上次启动未完成，可安全重试",
      taskConstraintLabel: "契约约束",
      taskStartPrerequisitesLabel: "启动前置条件",
      taskHoldReasonLabel: "待处理原因",
      taskNoUnknowns: "组织契约与任务范围已校验 · 可启动当前任务",
      taskUnknownFallback: "服务端返回未决项，需要人工核对",
      taskInputProof: "工作说明摘要已绑定 · {length} 个字符",
      taskConfirm: "确认范围并准入任务",
      taskAdmitted: "员工已确认 · 等待显式启动",
      taskAdmittedRetry: "员工已确认 · 启动未完成，可安全重试",
      taskStarting: "正在校验组织契约并启动任务…",
      taskStarted: "员工需求已确认，Agent 团队已启动",
      taskStartedBadge: "协作工作稿已形成",
      taskEvidenceUnavailable: "任务发起证据不可用",
      taskEvidenceUnavailableDetail: "报价已形成，但未观测到与当前运行绑定的持久化 Task Intake 收据；界面不推断员工已确认。",
      taskOacBound: "OAC 组织契约已精确绑定",
      taskOacOptional: "本部署未强制 OAC 激活绑定",
      taskBoundary: "工作说明（Prompt）不授予权限、不进入领域事实，也不会绕过后续产品与财务人工批准。当前已验证版本只处理企业报价任务。",
      taskError: "需求处理失败，请检查输入或企业契约状态。",
      taskIdentityError: "当前操作者与组织配置中的任务发起人不一致。",
      taskContractError: "OAC 组织契约尚未满足当前任务的启动条件。",
      taskReasonNames: {
        PROMPT_REQUIRED_OR_TOO_SHORT: "需求说明至少需要 8 个字符",
        PROMPT_TASK_INTENT_MISMATCH: "工作说明与当前已准入的企业报价任务不匹配",
        TASK_ACTOR_OUT_OF_PROFILE_SCOPE: "发起人不在当前组织配置范围内",
        CUSTOMER_OUT_OF_PROFILE_SCOPE: "客户不在当前已准入的任务范围内",
        DELIVERABLE_KIND_OUT_OF_PROFILE_SCOPE: "交付物类型未被当前模板准入",
        PROMPT_AUTHORITY_OVERRIDE_REQUESTED: "需求中存在绕过人工批准或权限的指令",
        OAC_ADAPTATION_EXACT_ENTERPRISE_PACK_REQUIRED: "OAC 企业材料尚未完成精确绑定",
        OAC_ADAPTATION_ACTIVATION_BINDING_REQUIRED: "OAC 激活绑定尚未完成",
      },
      taskUnknownNames: {
        task_intent: "任务目标",
        admitted_task_actor: "已准入发起人",
        admitted_customer: "已准入客户",
        admitted_deliverable_kind: "已准入交付物",
        requested_authority: "请求的权限",
        oac_activation_binding: "OAC 激活绑定",
      },
      skillCenterKicker: "跨运行能力治理",
      skillCenterTitle: "Agent 使用受版本管理的能力，经验只能经人审批后发布",
      skillCenterBody: "本页不参与当前报价决策。它把真实调用、已发布 Skill 与终态运行归纳的经验候选分开，防止 Agent 未经治理自动改写能力。",
      skillCenterBadge: "Skill 治理",
      skillCurrentTitle: "本次任务的能力调用",
      skillCurrentBoundary: "只在同一运行的 Agent、Skill 活动行与回执精确匹配后显示",
      skillCurrentAgent: "调用 Agent",
      skillCurrentCapability: "能力与版本",
      skillCurrentPurpose: "为什么调用",
      skillCurrentEffect: "结果与权威边界",
      skillCurrentWaiting: "等待当前任务产生 Skill 调用回执",
      skillPublishedTitle: "已发布能力",
      skillPublishedBoundary: "可发现 · 精确版本 · 评测后发布",
      skillExperienceTitle: "经验候选审阅",
      skillExperienceBoundary: "运行经验只是候选；人工决策是 Skill 发布批准，不是业务结果批准",
      skillLifecycle: "完成运行 → 经验候选 → 独立评测 → 人工决策 → 受控灰度试调用",
      publicEvidence: "附加验证 · BPI 2019",
      publicEvidenceDetail: "公开真实流程，不冒充报价数据",
    }),
    en: Object.freeze({
      product: "Enterprise Work Platform",
      workspaceLabel: "CURRENT WORK ITEM",
      workspaceName: "Blue Harbor Enterprise Quote",
      workspaceType: "Enterprise quote · controlled local",
      environment: "Controlled validation environment",
      operator: "Enterprise Quote Operator",
      lifecycleOnboarding: "Enterprise Onboarding",
      lifecycleOnboardingDetail: "LOW FREQUENCY · FIRST SETUP OR CONTRACT CHANGE",
      lifecycleDaily: "Daily Work",
      lifecycleDailyDetail: "HIGH FREQUENCY · EMPLOYEE WORK ITEMS",
      navigation: "ONBOARD ONCE · WORK CONTINUOUSLY",
      workspaceNavigationAria: "OrgRebase workspace navigation",
      lifecycleNavigationAria: "Workspace lifecycle",
      sectionDaily: "DAILY WORK",
      sectionDailyAssurance: "DAILY GOVERNANCE & ASSURANCE",
      sectionOnboarding: "ENTERPRISE ONBOARDING",
      pages: {
        overview: ["Overview", "See whether this workspace is onboarding or working", "The enterprise onboards once; employees then launch daily work governed by OAC."],
        quote: ["Work Item", "Start one work item as an employee", "The currently validated task type is Enterprise Quote: confirm the request, then a dynamic Agent team forms an internal working draft and completes two traceable selective changes."],
        data: ["Business Data Evolution", "See one task's data change", "Trace the employee request and least-privilege context through the collaborative working draft, launch-date confirmed draft, and currency confirmed draft, including rebuilds, retained evidence, and change-specific Owner approvals."],
        agents: ["Agent Collaboration", "See what every Agent did", "Inspect this run's actual topology, context handoffs, each Agent's Tool/Skill invocations, Review, and candidate acceptance."],
        acceptance: ["Task Acceptance", "Accept the current business task", "Summarizes only this run's verified responsibility chain, terminal receipts, and selective-Rebase result without borrowing from independent test archives."],
        materials: ["Onboarding Data", "What the enterprise provides once", "Shows how long-lived enterprise inputs enter a safe projection; the current employee task is not mixed into onboarding data."],
        oac: ["OAC Organization Contract", "Compile enterprise inputs into a durable runtime contract", "The Intake Agent proposes; the designated owner reviews admission, while the control plane retains authority."],
        skills: ["Capability Center", "Govern the capabilities Agents can use and evolve", "Review current invocations, released Skills, evaluation and rollback boundaries, then make human release decisions for experience candidates."],
        validation: ["Independent Validation", "Dynamic Formation & Control Semantics", "This page proves only on-demand formation, authority boundaries, conflict fencing, and scope reduction over a public real-world process. It is isolated from the active business run and does not execute the Quote task twice."],
        operations: ["Runtime Assurance", "Engineering evidence for enterprise operation", "Review OTLP, alerts, retention, capacity, recovery, deployment, SBOM, and production-validation boundaries."],
      },
      navState: { done: "DONE", current: "CURRENT", ready: "READY", waiting: "UP NEXT", audit: "AUDIT", loading: "LOADING", unavailable: "UNAVAILABLE" },
      pageKicker: "ORGREBASE ENTERPRISE WORKSPACE",
      currentStage: "CURRENT STAGE",
      currentRun: "CURRENT RUN",
      onboardingContext: "ONBOARDING STATUS",
      onboardingIdentity: "CONTRACT ACTIVATION IDENTITY",
      dailyAssuranceContext: "DAILY GOVERNANCE",
      dailyAssuranceIdentity: "RELATION TO CURRENT WORK ITEM",
      currentOrganization: "CURRENT ORGANIZATION",
      onboardingWorkspaceType: "OAC enterprise onboarding · controlled pilot",
      dailyAssuranceWorkspaceType: "Enterprise daily work · governance & assurance",
      dailyAssuranceFacts: {
        skills: ["CAPABILITY GOVERNANCE", "Current invocation + cross-run human release"],
        validation: ["INDEPENDENT MECHANISM EVIDENCE", "Does not execute the current Quote task again"],
        operations: ["ENGINEERING RUNTIME EVIDENCE", "Current run + independent assurance archives"],
      },
      onboardingPending: "Awaiting OAC admission",
      onboardingReady: "Organization contract active",
      onboardingConsumed: "Organization contract consumed by a task",
      onboardingIdentityPending: "Awaiting activation digest",
      onboardingIdentityBound: "Bound to this organization and Workspace",
      workspaceLoading: "Loading authoritative Workspace state",
      workspaceUnavailable: "Workspace state unavailable",
      overviewProblem: "THE ORIGINAL PROBLEM",
      overviewProblemValue: "One Quote change crosses Product, Legal, Finance, GTM, and several disconnected systems",
      overviewSolution: "HOW ORGREBASE HANDLES IT",
      overviewSolutionValue: "OAC fixes enterprise inputs, authority, and admission boundaries; task formation then compiles the minimum Agent team and context",
      overviewResult: "THE OUTCOME",
      overviewResultValue: "Owners click only at high-risk gates; the control plane applies selective writes with complete evidence",
      overviewFlowOnboarding: ["Enterprise inputs", "Candidate mapping", "Owner admission", "Organization contract active"],
      overviewFlowDaily: ["Employee request", "Constrained task", "Dynamic formation", "Collaborative working draft", "Two selective Rebases", "Currency confirmed draft"],
      openMaterials: "Continue onboarding",
      openOac: "Continue to organization-contract adaptation",
      viewActiveOac: "View active organization contract",
      openWorkItem: "Start a work request",
      continueWorkItem: "Continue current work item",
      viewCompletedWork: "View completed work item",
      materialsKicker: "ENTERPRISE INPUT MATURITY · AWAITING SERVER EVIDENCE",
      materialsTitle: "Five long-lived input classes compile into one organization contract",
      materialsBody: "The browser reads only an admitted safe projection. It presents the source classification and whether the inputs are controlled synthetic samples exactly as declared by the server. Current employee work and raw private values never enter onboarding materials.",
      materialClassSynthetic: "CONTROLLED SYNTHETIC ENTERPRISE SAMPLE · STRUCTURAL LOOP ONLY",
      materialClassObserved: "SERVER-DECLARED DATA CLASS: {dataClass}",
      materialClassUnclassified: "DATA CLASS NOT OBSERVED · MATURITY IS NOT INFERRED",
      materialClassUnavailable: "INPUT STATE UNAVAILABLE · NOT SHOWN AS LOADED",
      materialStatusReady: "Source admitted and matched to runtime configuration",
      materialStatusWaiting: "Awaiting safe input projection",
      pack: "ENTERPRISE INPUT PACK",
      organization: "ONBOARDED ORGANIZATION",
      profile: "ORGANIZATION PROFILE",
      actor: "TASK ACTOR",
      customer: "TARGET CUSTOMER",
      purpose: "PURPOSE",
      deliverable: "DELIVERABLE",
      template: "OUTPUT TEMPLATE",
      fiveRoots: "FIVE OAC ROOT INPUTS",
      facts: "ADMITTED ORGANIZATION FACTS",
      factsCount: "{count} safe-projection fields visible in this session",
      rootCount: "{count}/5 input classes loaded",
      inputToOutput: "FROM ENTERPRISE INPUT TO EXECUTABLE WORKSPACE",
      flowSource: "Enterprise inputs", flowSourceDetail: "facts, sources, authority, sensitivity",
      flowOac: "OAC contract", flowOacDetail: "domain, knowledge, authority, capability, dependency",
      flowContext: "Owner admission", flowContextDetail: "exact summary, Unknowns, and named authority",
      flowOutcome: "Organization contract active", flowOutcomeDetail: "future tasks remain bound by authority, capability, and context rules",
      loadedByConfig: "Safely loaded by startup configuration",
      exactVersionBound: "Exact version bound",
      materialPackName: "Current enterprise material pack",
      materialOrganizationName: "Current onboarded organization",
      componentComplete: "Complete",
      componentSource: "{component} material source",
      sourceRegistered: "{domain} source registered",
      authorityMatched: "{domain} authority owner matched",
      domainNames: { product: "Product", legal: "Legal", finance: "Finance", gtm: "GTM" },
      noSource: "The service has not returned an enterprise-input safe projection. This page will not fabricate one.",
      noValue: "Not supplied",
      source: "SOURCE", authority: "AUTHORITY", sensitivity: "SENSITIVITY", completeness: "COMPLETENESS", digest: "DIGEST",
      componentNames: { DOMAIN: "Domain", KNOWLEDGE: "Knowledge", AUTHORITY: "Authority", CAPABILITY: "Capability", DEPENDENCY: "Dependency" },
      slotNames: {
        product_plan: "Enterprise plan", launch_date: "Launch date", data_residency: "Data residency",
        notice_required: "Customer notice", price_band: "Price band", currency: "Quote currency",
        partner_terms: "Partner terms", quote_compose_skill: "Quote compose Skill", public_message: "Public message",
      },
      sensitivityNames: { PUBLIC: "Public", INTERNAL: "Internal", CONFIDENTIAL: "Confidential", RESTRICTED: "Restricted" },
      materialValueNames: {
        USD: "US dollars (USD)",
        "US and EU regions supported": "US and EU regions supported",
        "legal-review": "Legal review required",
        strategic: "Strategic-account pricing",
        "Evergreen Enterprise Plus": "Evergreen Enterprise Plus",
        "The enterprise launch remains on the approved schedule.": "The enterprise launch remains on the approved schedule.",
        "skill:enterprise-quote-compose@1.0": "Enterprise quote composition Skill",
      },
      materialPackNames: { "pack:evergreen-enterprise-quote@r1": "Evergreen Industries enterprise quote onboarding pack" },
      organizationNames: { "org:evergreen-industries": "Evergreen Industries" },
      customerNames: { "customer:blue-harbor": "Blue Harbor customer" },
      routeUnavailable: "Page unavailable",
      routeUnavailableBody: "The corresponding product component did not load. Nothing was fabricated.",
      routeNext: "Next",
      stageNames: {
        EMPTY: "Awaiting employee request", QUOTE_V1: "Internal working draft formed", LAUNCH_PREVIEWED: "Product-date change awaiting approval", LAUNCH_APPROVED: "Product-date change approved · awaiting apply",
        QUOTE_V2: "Product-date change applied", CURRENCY_PREVIEWED: "Currency change awaiting approval", CURRENCY_APPROVED: "Currency change approved · awaiting apply", QUOTE_V3: "Internal change loop verified",
      },
      runPending: "Business run awaiting formation", runAwaitingEmployee: "Business run starts after employee request", runCandidatePending: "Business run starts after employee confirmation", runActive: "Business run in progress", runComplete: "Internal change loop verified",
      taskCandidateStage: "Task candidate awaiting confirmation",
      caseBadge: "CURRENT WORK ITEM",
      taskIntakeKicker: "SERVER TASK ENTRYPOINT · VALIDATED TYPE: ENTERPRISE QUOTE",
      taskIntakeTitle: "Describe this work item before validation produces a constrained task candidate",
      taskIntakeBody: "The description confirms that the employee is requesting the currently admitted Enterprise Quote task; unrelated requests are held for human resolution. Customer, deliverable, facts, and authority still come only from the admitted contract and are never extracted or expanded from the Prompt.",
      taskCompletedKicker: "EMPLOYEE INTAKE RECORD · BOUND TO THIS RUN",
      taskCompletedTitle: "Employee request confirmed",
      taskCompletedBody: "The work description was validated and the Agent team was started. Customer, facts, and authority remained constrained by the admitted organization contract.",
      taskPromptLabel: "WORK ITEM DESCRIPTION",
      taskPromptExample: "Create an enterprise quote for Blue Harbor that follows current Product, Legal, Finance, and GTM rules.",
      taskPrivateTitle: "EMPLOYEE-SUBMITTED WORK DESCRIPTION",
      taskPrivateScope: "Visible only to the current task actor · excluded from public evidence, events, and telemetry",
      taskPrivateLoading: "Loading the private work description for this task…",
      taskPrivateNotRetained: "This run has no retained, verifiable employee work-description text. The system will not reconstruct one from a digest.",
      taskPrivateUnavailable: "The private work description cannot be read now. Display stopped; no digest-derived substitute is shown.",
      taskActorLabel: "REQUESTED BY",
      taskCustomerLabel: "CUSTOMER",
      taskKindLabel: "VALIDATED TASK TYPE",
      taskKindValue: "Enterprise Quote",
      taskContractLabel: "ORGANIZATION CONTRACT",
      taskContractReady: "Ready · server-verified at start",
      taskContractBlocked: "Enterprise onboarding is incomplete",
      taskCompleteOnboarding: "Complete enterprise onboarding first",
      taskPrepare: "Validate description and create candidate",
      taskPreparing: "Validating and creating constrained candidate…",
      taskAdmit: "Confirm scope and admit task",
      taskAdmitting: "Binding employee confirmation…",
      taskAdmittedButton: "Task admitted",
      taskRun: "Start Agent team",
      taskRunning: "Starting Agent team…",
      taskCandidateTitle: "CONSTRAINED TASK CANDIDATE",
      taskCandidateReady: "Awaiting employee confirmation",
      taskCandidateHold: "Held for human resolution",
      taskTemplateLabel: "SELECTED TEMPLATE",
      taskTemplateValue: "Enterprise Quote standard template",
      taskDigestLabel: "START EVIDENCE",
      taskChainProof: "Employee candidate confirmed · organization contract verified · Agent team started",
      taskCandidateProof: "Candidate created · awaiting employee confirmation",
      taskHoldProof: "Work-intent validation did not pass · Agent team not started",
      taskAdmittedProof: "Employee confirmation bound · waiting to start the Agent team",
      taskAdmittedRetryProof: "Employee confirmation bound · previous start incomplete, safe to retry",
      taskConstraintLabel: "CONTRACT CONSTRAINTS",
      taskStartPrerequisitesLabel: "START PREREQUISITES",
      taskHoldReasonLabel: "HOLD REASONS",
      taskNoUnknowns: "Organization contract and task scope verified · task may start",
      taskUnknownFallback: "The server returned an unresolved item that needs human review",
      taskInputProof: "Work-description digest bound · {length} characters",
      taskConfirm: "Confirm scope and admit task",
      taskAdmitted: "Employee confirmed · waiting for an explicit start",
      taskAdmittedRetry: "Employee confirmed · start incomplete, safe to retry",
      taskStarting: "Checking the organization contract and starting the task…",
      taskStarted: "Employee request confirmed; Agent team started",
      taskStartedBadge: "COLLABORATIVE WORKING DRAFT FORMED",
      taskEvidenceUnavailable: "TASK INTAKE EVIDENCE UNAVAILABLE",
      taskEvidenceUnavailableDetail: "A Quote exists, but no durable Task Intake receipt bound to the current run was observed. The UI does not infer employee confirmation.",
      taskOacBound: "OAC organization contract exactly bound",
      taskOacOptional: "This deployment does not require an OAC activation binding",
      taskBoundary: "A work description (Prompt) grants no authority, contributes no domain facts, and cannot bypass later Product or Finance approvals. This MVP validates only Enterprise Quote work.",
      taskError: "Request handling failed. Check the input or organization-contract state.",
      taskIdentityError: "The current operator does not match the task actor admitted by the organization profile.",
      taskContractError: "The OAC organization contract has not satisfied this task's start conditions.",
      taskReasonNames: {
        PROMPT_REQUIRED_OR_TOO_SHORT: "The work request must contain at least 8 characters",
        PROMPT_TASK_INTENT_MISMATCH: "The work description does not match the currently admitted Enterprise Quote task",
        TASK_ACTOR_OUT_OF_PROFILE_SCOPE: "The actor is outside the admitted organization profile",
        CUSTOMER_OUT_OF_PROFILE_SCOPE: "The customer is outside the admitted task scope",
        DELIVERABLE_KIND_OUT_OF_PROFILE_SCOPE: "The deliverable is not admitted by this template",
        PROMPT_AUTHORITY_OVERRIDE_REQUESTED: "The request attempts to bypass an approval or authority boundary",
        OAC_ADAPTATION_EXACT_ENTERPRISE_PACK_REQUIRED: "The exact OAC enterprise-input binding is incomplete",
        OAC_ADAPTATION_ACTIVATION_BINDING_REQUIRED: "The OAC activation binding is incomplete",
      },
      taskUnknownNames: {
        task_intent: "task intent",
        admitted_task_actor: "admitted task actor",
        admitted_customer: "admitted customer",
        admitted_deliverable_kind: "admitted deliverable",
        requested_authority: "requested authority",
        oac_activation_binding: "OAC activation binding",
      },
      skillCenterKicker: "CROSS-RUN CAPABILITY GOVERNANCE",
      skillCenterTitle: "Agents use versioned capabilities; experience is released only after human review",
      skillCenterBody: "This page does not make the current Quote decision. It separates exact invocations, released Skills, and experience candidates distilled from terminal runs so Agents cannot rewrite their own capabilities without governance.",
      skillCenterBadge: "Skill Governance",
      skillCurrentTitle: "CAPABILITY INVOCATION IN THIS TASK",
      skillCurrentBoundary: "Shown only after the Agent, same-run Skill activity row, and receipt match exactly",
      skillCurrentAgent: "CALLING AGENT",
      skillCurrentCapability: "CAPABILITY & VERSION",
      skillCurrentPurpose: "WHY IT WAS CALLED",
      skillCurrentEffect: "RESULT & AUTHORITY BOUNDARY",
      skillCurrentWaiting: "Awaiting a Skill invocation receipt from the current task",
      skillPublishedTitle: "RELEASED CAPABILITIES",
      skillPublishedBoundary: "DISCOVERABLE · EXACT VERSION · EVALUATED RELEASE",
      skillExperienceTitle: "EXPERIENCE CANDIDATE REVIEW",
      skillExperienceBoundary: "Run experience remains a candidate; this human decision approves a Skill release, not a business result",
      skillLifecycle: "Terminal run → Experience candidate → Independent evaluation → Human decision → Controlled CANARY dry-run",
      publicEvidence: "ADD-ON VALIDATION · BPI 2019",
      publicEvidenceDetail: "Real public process; not Quote data",
    }),
  });

  const byId = (id) => document.getElementById(id);
  const html = (value) => String(value ?? "").replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;",
  })[character]);
  const short = (value, width = 18) => {
    const text = String(value || "—");
    return text.length <= width ? text : `${text.slice(0, Math.max(8, width - 7))}…${text.slice(-6)}`;
  };
  const format = (template, values) => Object.entries(values || {}).reduce(
    (result, [key, value]) => result.replaceAll(`{${key}}`, String(value)), template,
  );

  let language = document.documentElement.lang === "en" ? "en" : "zh-CN";
  let currentRoute = "overview";
  let currentState = null;
  let stateAvailability = "loading";
  let currentOac = null;
  let activeLifecycle = "daily";
  let taskCandidate = null;
  let taskApproval = null;
  let taskIntakeBusy = false;
  let taskIntakeAction = "idle";
  let taskIntakeError = null;
  let taskWorkDescription = null;
  let taskWorkDescriptionRunId = null;
  let taskWorkDescriptionStatus = "idle";
  let shell = null;
  let pages = new Map();

  function copy() { return COPY[language]; }
  function routeFromHash() {
    const raw = String(window.location.hash || "").replace(/^#\/?/, "").split(/[?&]/)[0];
    const route = ROUTE_ALIASES[raw] || raw;
    return ROUTES.some((item) => item.id === route) ? route : "overview";
  }

  function routeDescriptor(route) {
    return ROUTES.find((item) => item.id === route) || ROUTES[0];
  }

  function navigationLifecycleVisible(routeLifecycle, lifecycle = activeLifecycle) {
    return routeLifecycle === lifecycle;
  }

  function make(tag, className, attributes = {}) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    Object.entries(attributes).forEach(([key, value]) => {
      if (key === "text") node.textContent = value;
      else node.setAttribute(key, value);
    });
    return node;
  }

  function page(id) {
    const section = make("section", "shell-page", { "data-page": id, "aria-labelledby": "shell-page-title" });
    section.hidden = true;
    pages.set(id, section);
    return section;
  }

  function unavailable(route) {
    const card = make("article", "shell-unavailable");
    card.innerHTML = `<strong>${html(copy().routeUnavailable)}</strong><p>${html(copy().routeUnavailableBody)}</p>`;
    card.dataset.route = route;
    return card;
  }

  function buildOverview() {
    const section = page("overview");
    const dashboard = make("section", "overview-dashboard");
    dashboard.innerHTML = `
      <article><span data-shell-copy="overviewProblem"></span><strong data-shell-copy="overviewProblemValue"></strong></article>
      <article><span data-shell-copy="overviewSolution"></span><strong data-shell-copy="overviewSolutionValue"></strong></article>
      <article class="accent"><span data-shell-copy="overviewResult"></span><strong data-shell-copy="overviewResultValue"></strong></article>`;
    section.append(dashboard);
    const flow = make("section", "overview-flow-card");
    flow.innerHTML = `<div class="overview-flow" id="shell-overview-flow"></div><button type="button" class="shell-next" data-route-target="materials"></button>`;
    section.append(flow);
    const legacyHero = document.querySelector(".hero");
    if (legacyHero) {
      legacyHero.hidden = true;
      section.append(legacyHero);
    }
    const complexityBridge = document.querySelector(".complexity-bridge");
    if (complexityBridge) section.append(complexityBridge);
    return section;
  }

  function buildMaterials() {
    const section = page("materials");
    const intro = make("section", "materials-intro");
    intro.innerHTML = `
      <div><span data-shell-copy="materialsKicker"></span><h2 data-shell-copy="materialsTitle"></h2><p data-shell-copy="materialsBody"></p></div>
      <span class="material-admission" id="shell-material-status"></span>`;
    section.append(intro);
    const facts = make("section", "material-summary", { id: "shell-material-summary", "aria-live": "polite" });
    facts.innerHTML = `<p>${html(copy().noSource)}</p>`;
    section.append(facts);
    const flow = make("section", "input-output-flow");
    flow.innerHTML = `
      <h3 data-shell-copy="inputToOutput"></h3>
      <div class="input-output-steps">
        <article><b>01</b><strong data-shell-copy="flowSource"></strong><small data-shell-copy="flowSourceDetail"></small></article><i>→</i>
        <article><b>02</b><strong data-shell-copy="flowOac"></strong><small data-shell-copy="flowOacDetail"></small></article><i>→</i>
        <article><b>03</b><strong data-shell-copy="flowContext"></strong><small data-shell-copy="flowContextDetail"></small></article><i>→</i>
        <article><b>04</b><strong data-shell-copy="flowOutcome"></strong><small data-shell-copy="flowOutcomeDetail"></small></article>
      </div>
      <button type="button" class="shell-next" data-route-target="oac" data-shell-copy="openOac"></button>`;
    section.append(flow);
    return section;
  }

  function buildTaskIntake() {
    const section = make("section", "task-intake", { id: "task-intake", "aria-labelledby": "task-intake-title" });
    section.innerHTML = `
      <header class="task-intake-head">
        <div><span id="task-intake-kicker" data-shell-copy="taskIntakeKicker"></span><h2 id="task-intake-title" data-shell-copy="taskIntakeTitle"></h2><p id="task-intake-body" data-shell-copy="taskIntakeBody"></p></div>
        <b id="task-intake-contract"></b>
      </header>
      <div class="task-intake-form" id="task-intake-form">
        <label for="task-request-prompt"><span data-shell-copy="taskPromptLabel"></span><textarea id="task-request-prompt" rows="3" maxlength="500" autocomplete="off" spellcheck="false"></textarea></label>
        <dl class="task-intake-scope">
          <div><dt data-shell-copy="taskActorLabel"></dt><dd id="task-intake-actor">—</dd></div>
          <div><dt data-shell-copy="taskCustomerLabel"></dt><dd id="task-intake-customer">—</dd></div>
          <div><dt data-shell-copy="taskKindLabel"></dt><dd data-shell-copy="taskKindValue"></dd></div>
        </dl>
        <button type="button" class="button button-primary" id="task-intake-prepare" data-shell-copy="taskPrepare"></button>
      </div>
      <section class="task-intake-private" id="task-intake-private" hidden aria-live="polite">
        <header><strong data-shell-copy="taskPrivateTitle"></strong><span data-shell-copy="taskPrivateScope"></span></header>
        <p id="task-intake-private-text"></p>
      </section>
      <section class="task-intake-candidate" id="task-intake-candidate" hidden aria-live="polite">
        <header><div><span data-shell-copy="taskCandidateTitle"></span><strong id="task-intake-candidate-status"></strong></div><b id="task-intake-candidate-badge"></b></header>
        <dl>
          <div><dt data-shell-copy="taskTemplateLabel"></dt><dd id="task-intake-template">—</dd></div>
          <div><dt data-shell-copy="taskDigestLabel"></dt><dd class="mono" id="task-intake-digest">—</dd></div>
          <div><dt id="task-intake-third-label" data-shell-copy="taskStartPrerequisitesLabel"></dt><dd id="task-intake-unknowns">—</dd></div>
        </dl>
        <div class="task-intake-actions">
          <button type="button" class="button button-secondary" id="task-intake-admit" data-shell-copy="taskAdmit"></button>
          <button type="button" class="button button-primary" id="task-intake-run" data-shell-copy="taskRun" hidden></button>
        </div>
      </section>
      <p class="task-intake-error" id="task-intake-error" hidden></p>
      <p class="task-intake-boundary" data-shell-copy="taskBoundary"></p>`;
    return section;
  }

  function buildFromExisting(route, node, options = {}) {
    const section = page(route);
    if (node) {
      if (options.open && node.tagName === "DETAILS") node.open = true;
      if (node.getAttribute("role") === "tabpanel") {
        node.removeAttribute("role");
        node.removeAttribute("aria-labelledby");
      }
      node.hidden = false;
      section.append(node);
    } else section.append(unavailable(route));
    return section;
  }

  function buildShell() {
    const main = document.querySelector("main");
    if (!main || byId("enterprise-app-shell")) return;
    const originalTopbar = document.querySelector(".topbar");
    const oldCockpit = document.querySelector(".evidence-cockpit");
    const originalFooter = document.querySelector("body > footer");

    shell = make("div", "enterprise-app-shell", { id: "enterprise-app-shell" });
    const sidebar = make("aside", "shell-sidebar", {
      "aria-label": copy().workspaceNavigationAria,
      "data-shell-aria-label": "workspaceNavigationAria",
    });
    sidebar.innerHTML = `
      <div class="shell-brand"><span>知</span><div><strong>OrgRebase</strong><small data-shell-copy="product"></small></div></div>
      <div class="shell-lifecycle-switch" role="group" aria-label="${copy().lifecycleNavigationAria}" data-shell-aria-label="lifecycleNavigationAria">
        <button type="button" data-lifecycle-target="onboarding" aria-pressed="false"><strong data-shell-copy="lifecycleOnboarding"></strong><small data-shell-copy="lifecycleOnboardingDetail"></small></button>
        <button type="button" data-lifecycle-target="daily" aria-pressed="false"><strong data-shell-copy="lifecycleDaily"></strong><small data-shell-copy="lifecycleDailyDetail"></small></button>
      </div>
      <div class="shell-case">
        <span id="shell-case-label" data-shell-copy="workspaceLabel"></span>
        <strong id="shell-case-name" data-shell-copy="workspaceName"></strong>
        <small id="shell-case-type" data-shell-copy="workspaceType"></small>
        <b id="shell-case-stage"></b>
      </div>
      <p class="shell-nav-intro" data-shell-copy="navigation"></p>
      <nav class="shell-nav" id="shell-navigation"></nav>
      <div class="shell-sidebar-evidence">
        <span data-shell-copy="publicEvidence"></span>
        <small data-shell-copy="publicEvidenceDetail"></small>
      </div>
      <div class="shell-sidebar-foot"><span class="shell-live-dot"></span><span data-shell-copy="environment"></span></div>`;
    const nav = sidebar.querySelector("#shell-navigation");
    let previousSection = null;
    ROUTES.forEach((route) => {
      if (route.section !== previousSection) {
        const sectionKey = route.section === "daily"
          ? "sectionDaily"
          : route.section === "daily-assurance"
            ? "sectionDailyAssurance"
            : "sectionOnboarding";
        const label = make("span", "shell-nav-section", {
          "data-shell-copy": sectionKey,
          "data-nav-lifecycle": route.lifecycle,
          "data-nav-section": route.section,
        });
        nav.append(label);
        previousSection = route.section;
      }
      const button = make("button", "shell-nav-item", {
        type: "button",
        "data-route": route.id,
        "data-nav-lifecycle": route.lifecycle,
        "data-nav-section": route.section,
      });
      button.innerHTML = `<span class="shell-nav-icon">${html(route.icon)}</span><span class="shell-nav-label"></span><small class="shell-nav-state"></small>`;
      button.addEventListener("click", () => navigate(route.id));
      nav.append(button);
    });
    sidebar.querySelectorAll("[data-lifecycle-target]").forEach((button) => {
      button.addEventListener("click", () => {
        const target = button.dataset.lifecycleTarget;
        navigate(target === "onboarding" ? "materials" : "quote");
      });
    });

    const content = make("div", "shell-content");
    if (originalTopbar) content.append(originalTopbar);
    const pageHeader = make("header", "shell-page-header", { id: "shell-page-header" });
    pageHeader.innerHTML = `
      <div><span data-shell-copy="pageKicker"></span><h1 id="shell-page-title"></h1><p id="shell-page-summary"></p></div>
      <div class="shell-page-facts"><span><small id="shell-context-label" data-shell-copy="currentStage"></small><strong id="shell-stage"></strong></span><span><small id="shell-identity-label" data-shell-copy="currentRun"></small><strong id="shell-run"></strong></span></div>`;
    content.append(pageHeader);
    const pageRoot = make("div", "shell-pages", { id: "shell-pages" });
    content.append(pageRoot);
    shell.append(sidebar, content);
    document.body.insertBefore(shell, main);
    main.classList.add("shell-main");
    pageRoot.append(main);

    const overview = buildOverview();
    const materials = buildMaterials();
    const oac = buildFromExisting("oac", byId("oac-adaptation"), { open: true });
    const quote = page("quote");
    quote.append(buildTaskIntake());
    [document.querySelector(".journey"), byId("command-bar"), byId("workspace")].forEach((node) => {
      if (node) quote.append(node);
    });
    if (!quote.children.length) quote.append(unavailable("quote"));

    const data = buildFromExisting("data", byId("cockpit-scene"));
    const agents = buildFromExisting("agents", byId("cockpit-collaboration"));
    const acceptance = buildFromExisting("acceptance", byId("current-task-acceptance"));
    const skills = buildFromExisting("skills", byId("cockpit-skills"));
    const validation = buildFromExisting("validation", byId("cockpit-value"));
    const operations = buildFromExisting("operations", byId("cockpit-operations"));
    [overview, materials, oac, quote, data, agents, acceptance, skills, validation, operations].forEach((node) => main.append(node));

    if (oldCockpit) oldCockpit.hidden = true;
    const preflightMount = byId("oac-preflight-mount");
    if (preflightMount) preflightMount.remove();
    if (originalFooter) originalFooter.hidden = true;
    document.body.classList.add("shell-ready");
  }

  function positionPlatformGovernance() {
    const publishedSkills = byId("retained-skills");
    const publishedMount = byId("published-skills-mount");
    if (publishedSkills && publishedMount && publishedSkills.parentElement !== publishedMount) {
      publishedMount.append(publishedSkills);
    }
    const experience = byId("experience-governance");
    const experienceMount = byId("experience-governance-mount");
    if (experience && experienceMount && experience.parentElement !== experienceMount) {
      experienceMount.append(experience);
    }
    const retainedMechanism = byId("retained-mechanism");
    const validationView = byId("cockpit-value");
    const publicValidation = byId("public-real-process-validation");
    if (retainedMechanism && validationView && retainedMechanism.parentElement !== validationView) {
      retainedMechanism.open = false;
      validationView.insertBefore(retainedMechanism, publicValidation || null);
    }
  }

  function positionCurrentRunProof() {
    const currentRunProof = byId("ops-current-run-proof");
    const acceptancePage = pages.get("acceptance");
    if (currentRunProof && acceptancePage && currentRunProof.parentElement !== acceptancePage) {
      acceptancePage.append(currentRunProof);
    }
  }

  function organizationContractReady(state = currentState) {
    const activation = state && state.execution && state.execution.oac_activation || {};
    const runtimeReady = ["READY_TO_FORM", "CONSUMED_BY_QUOTE_FORMATION"].includes(activation.status);
    const observedGate = currentOac && currentOac.workspaceGate;
    if (observedGate) return observedGate.valid !== false && observedGate.formAllowed === true;
    return runtimeReady;
  }

  function onboardingContext(state = currentState) {
    const selected = copy();
    const activation = state && state.execution && state.execution.oac_activation || {};
    const gate = currentOac && currentOac.workspaceGate || {};
    const gateObserved = Boolean(currentOac && currentOac.workspaceGate);
    const status = (gateObserved ? gate.status : activation.status) || "BLOCKED_PENDING_OAC";
    const digest = (gateObserved ? gate.activationBindingDigest || gate.activation_binding_digest : null)
      || activation.activation_binding_digest
      || gate.activation_binding_digest
      || null;
    const label = status === "CONSUMED_BY_QUOTE_FORMATION"
      ? selected.onboardingConsumed
      : organizationContractReady(state)
        ? selected.onboardingReady
        : selected.onboardingPending;
    return { status, label, digest };
  }

  function setExactText(node, value) {
    if (!node) return;
    node.textContent = value;
    node.removeAttribute("title");
  }

  function renderContextFacts(state = currentState) {
    const selected = copy();
    const contextLabel = byId("shell-context-label");
    const identityLabel = byId("shell-identity-label");
    const contextValue = byId("shell-stage");
    const identityValue = byId("shell-run");
    const caseLabel = byId("shell-case-label");
    const caseName = byId("shell-case-name");
    const caseType = byId("shell-case-type");
    const caseStage = byId("shell-case-stage");
    const scenario = state && state.scenario || {};

    if (activeLifecycle === "onboarding") {
      contextLabel.textContent = selected.onboardingContext;
      identityLabel.textContent = selected.onboardingIdentity;
      caseLabel.textContent = selected.currentOrganization;
      caseName.textContent = selected.organizationNames[String(scenario.organization_id || "")]
        || scenario.organization_name
        || selected.materialOrganizationName;
      caseType.textContent = selected.onboardingWorkspaceType;
    } else {
      const assuranceFacts = selected.dailyAssuranceFacts[currentRoute];
      contextLabel.textContent = assuranceFacts ? selected.dailyAssuranceContext : selected.currentStage;
      identityLabel.textContent = assuranceFacts ? selected.dailyAssuranceIdentity : selected.currentRun;
      caseLabel.textContent = selected.workspaceLabel;
      const customerName = selected.customerNames[String(scenario.customer_id || "")];
      caseName.textContent = customerName
        ? `${customerName} · ${selected.taskKindValue}`
        : scenario.label || selected.workspaceName;
      caseType.textContent = assuranceFacts ? selected.dailyAssuranceWorkspaceType : selected.workspaceType;
    }

    if (stateAvailability !== "ready" || !state || !STAGES.includes(state.stage)) {
      const unavailable = stateAvailability === "unavailable";
      const status = unavailable ? selected.workspaceUnavailable : selected.workspaceLoading;
      setExactText(contextValue, status);
      setExactText(identityValue, status);
      setExactText(caseStage, status);
      return;
    }

    if (activeLifecycle === "onboarding") {
      const onboarding = onboardingContext(state);
      setExactText(contextValue, onboarding.label, onboarding.status);
      setExactText(
        identityValue,
        onboarding.digest ? selected.onboardingIdentityBound : selected.onboardingIdentityPending,
        onboarding.digest,
      );
      setExactText(caseStage, onboarding.label, onboarding.status);
      return;
    }
    const assuranceFacts = selected.dailyAssuranceFacts[currentRoute];
    if (assuranceFacts) {
      setExactText(contextValue, assuranceFacts[0]);
      setExactText(identityValue, assuranceFacts[1]);
      setExactText(caseStage, selected.pages[currentRoute][0]);
      return;
    }

    const runId = state.execution && state.execution.run_id;
    const candidateReady = state.stage === "EMPTY"
      && taskCandidate
      && taskCandidate.status === "READY_FOR_CONFIRMATION";
    const visibleStage = candidateReady ? selected.taskCandidateStage : stageName(state.stage);
    setExactText(contextValue, visibleStage, candidateReady ? taskCandidate.digest : state.stage);
    setExactText(
      identityValue,
      candidateReady
        ? selected.runCandidatePending
        : runId
        ? state.stage === "EMPTY"
          ? selected.runAwaitingEmployee
          : state.stage === "QUOTE_V3"
            ? selected.runComplete
            : selected.runActive
        : selected.runPending,
      candidateReady ? taskCandidate.digest : runId,
    );
    setExactText(caseStage, visibleStage, candidateReady ? taskCandidate.digest : state.stage);
  }

  function renderOverviewFlow(state = currentState) {
    const selected = copy();
    const ready = organizationContractReady(state);
    const steps = ready ? selected.overviewFlowDaily : selected.overviewFlowOnboarding;
    const overviewFlow = byId("shell-overview-flow");
    if (overviewFlow) overviewFlow.innerHTML = steps.map((item, index) => (
      `<span><b>${String(index + 1).padStart(2, "0")}</b><strong>${html(item)}</strong></span>${index < steps.length - 1 ? "<i>→</i>" : ""}`
    )).join("");
    const next = document.querySelector('[data-route-target]');
    if (next) {
      next.dataset.routeTarget = ready ? "quote" : "materials";
      const candidateReady = taskCandidate && taskCandidate.status === "READY_FOR_CONFIRMATION";
      const dailyAction = state && state.stage === "QUOTE_V3"
        ? selected.viewCompletedWork
        : state && (state.stage !== "EMPTY" || candidateReady)
          ? selected.continueWorkItem
          : selected.openWorkItem;
      next.textContent = `${ready ? dailyAction : selected.openMaterials}  →`;
    }
    const materialsNext = document.querySelector('.shell-page[data-page="materials"] [data-route-target="oac"]');
    if (materialsNext) {
      materialsNext.textContent = organizationContractReady(state) ? selected.viewActiveOac : selected.openOac;
    }
  }

  function renderLifecycle() {
    if (!shell) return;
    shell.dataset.lifecycle = activeLifecycle;
    document.querySelectorAll("[data-lifecycle-target]").forEach((button) => {
      const active = button.dataset.lifecycleTarget === activeLifecycle;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
    });
    document.querySelectorAll("[data-nav-lifecycle]").forEach((node) => {
      node.hidden = !navigationLifecycleVisible(node.dataset.navLifecycle);
    });
  }

  function setCopy() {
    const selected = copy();
    document.querySelectorAll("[data-shell-copy]").forEach((node) => {
      const key = node.dataset.shellCopy;
      const value = selected[key];
      if (typeof value === "string") node.textContent = value;
    });
    document.querySelectorAll("[data-shell-aria-label]").forEach((node) => {
      const key = node.dataset.shellAriaLabel;
      const value = selected[key];
      if (typeof value === "string") node.setAttribute("aria-label", value);
    });
    ROUTES.forEach((route) => {
      const button = document.querySelector(`[data-route="${route.id}"]`);
      if (!button) return;
      button.querySelector(".shell-nav-label").textContent = selected.pages[route.id][0];
    });
    renderOverviewFlow(currentState);
    renderLifecycle();
    document.querySelectorAll("[data-route-target]").forEach((button) => {
      if (button.dataset.bound) return;
      button.dataset.bound = "true";
      button.addEventListener("click", () => navigate(button.dataset.routeTarget));
    });
    renderRouteHeader();
    renderState(currentState);
  }

  function stageIndex(stage) {
    const index = STAGES.indexOf(stage);
    return index < 0 ? 0 : index;
  }

  function stageName(stage) {
    return copy().stageNames[stage] || String(stage || copy().stageNames.EMPTY);
  }

  function runSummary(state) {
    if (!state || state.stage === "EMPTY") return copy().runPending;
    if (state.stage === "QUOTE_V3") return copy().runComplete;
    return copy().runActive;
  }

  function navState(route, state) {
    const stage = state && state.stage || "EMPTY";
    const index = stageIndex(stage);
    const source = state && state.enterprise_data_lineage && state.enterprise_data_lineage.source || {};
    const oac = state && state.execution && state.execution.oac_activation || {};
    const competition = state && state.competition_evidence;
    if (route === "overview") return "done";
    if (route === "materials") return source.status === "ADMITTED_AND_MATCHED" ? "done" : "current";
    if (route === "oac") {
      if (organizationContractReady(state)) return "done";
      return currentRoute === "oac" ? "current" : "ready";
    }
    if (route === "quote") return stage === "QUOTE_V3" ? "done" : (index > 0 || currentRoute === "quote" ? "current" : "ready");
    if (route === "data") return index > 0 ? (stage === "QUOTE_V3" ? "done" : "current") : "waiting";
    if (route === "agents") return competition ? "done" : (index > 0 ? "current" : "waiting");
    if (route === "acceptance") return stage === "QUOTE_V3" ? "done" : (index > 0 ? "current" : "waiting");
    if (route === "skills" || route === "validation" || route === "operations") return "audit";
    return "waiting";
  }

  function renderRouteHeader() {
    const selected = copy();
    const descriptor = selected.pages[currentRoute] || selected.pages.overview;
    const title = byId("shell-page-title");
    const summary = byId("shell-page-summary");
    if (title) title.textContent = descriptor[1];
    if (summary) summary.textContent = `${descriptor[0]} · ${descriptor[2]}`;
    document.title = `${descriptor[0]}｜OrgRebase`;
    renderContextFacts(currentState);
  }

  function activate(route, { focus = false } = {}) {
    const next = ROUTES.some((item) => item.id === route) ? route : "overview";
    const descriptor = routeDescriptor(next);
    activeLifecycle = next === "overview"
      ? (organizationContractReady(currentState) ? "daily" : "onboarding")
      : descriptor.lifecycle;
    currentRoute = next;
    pages.forEach((node, id) => {
      const active = id === next;
      node.hidden = !active;
      node.classList.toggle("active", active);
    });
    document.querySelectorAll(".shell-nav-item").forEach((button) => {
      const active = button.dataset.route === next;
      button.classList.toggle("active", active);
      button.setAttribute("aria-current", active ? "page" : "false");
    });
    renderLifecycle();
    const cockpitRoute = { data: "scene", agents: "collaboration", skills: "skills", validation: "value", operations: "operations" }[next];
    if (cockpitRoute) {
      const tab = document.querySelector(`.cockpit-tab[data-view="${cockpitRoute}"]`);
      if (tab) tab.click();
      const view = pages.get(next) && pages.get(next).querySelector(".cockpit-view");
      if (view) view.hidden = false;
    }
    positionCurrentRunProof();
    if (next === "oac") {
      const panel = byId("oac-adaptation");
      if (panel) panel.open = true;
    }
    renderRouteHeader();
    renderState(currentState);
    window.scrollTo({ top: 0, behavior: focus ? "smooth" : "auto" });
    if (focus) {
      const heading = byId("shell-page-title");
      if (heading) {
        heading.tabIndex = -1;
        heading.focus({ preventScroll: true });
      }
    }
  }

  function navigate(route) {
    const next = ROUTE_ALIASES[route] || route;
    const hash = `#/${next}`;
    if (window.location.hash === hash) activate(next, { focus: true });
    else window.location.hash = hash;
  }

  function renderMaterials(state) {
    const selected = copy();
    const root = byId("shell-material-summary");
    const status = byId("shell-material-status");
    const maturity = document.querySelector('[data-shell-copy="materialsKicker"]');
    if (!root || !status || !maturity) return;
    const lineage = state && state.enterprise_data_lineage || {};
    const source = lineage.source || {};
    const scenario = state && state.scenario || {};
    const profile = state && state.enterprise_seed_profile || {};
    const dataClass = String(lineage.data_class || profile.data_class || state && state.boundaries && state.boundaries.data_profile || "").trim();
    const synthetic = scenario.synthetic === true || dataClass === "SYNTHETIC_FIXTURE";
    const components = Array.isArray(source.components) ? source.components : [];
    const values = Array.isArray(source.values) ? source.values : [];
    const observedKinds = new Set(components.map((item) => String(item && item.kind || "").toUpperCase()));
    const ready = source.status === "ADMITTED_AND_MATCHED"
      && components.length === COMPONENTS.length
      && observedKinds.size === COMPONENTS.length
      && COMPONENTS.every((kind) => observedKinds.has(kind))
      && components.every((item) => (
        item && item.completeness === "COMPLETE"
        && Array.isArray(item.source_root_refs)
        && item.source_root_refs.length > 0
        && /^sha256:[0-9a-f]{64}$/.test(String(item.declared_digest || ""))
      ));
    maturity.textContent = stateAvailability === "unavailable"
      ? selected.materialClassUnavailable
      : synthetic
        ? selected.materialClassSynthetic
        : dataClass
          ? format(selected.materialClassObserved, { dataClass })
          : selected.materialClassUnclassified;
    maturity.removeAttribute("title");
    status.textContent = ready ? selected.materialStatusReady : selected.materialStatusWaiting;
    status.dataset.state = ready ? "ready" : "waiting";
    if (!ready) {
      root.innerHTML = `<article class="material-empty"><strong>${html(selected.materialStatusWaiting)}</strong><p>${html(selected.noSource)}</p></article>`;
      return;
    }
    const componentMap = new Map(components.map((item) => [String(item.kind || "").toUpperCase(), item]));
    const componentCards = COMPONENTS.map((kind) => {
      const item = componentMap.get(kind) || {};
      const componentName = selected.componentNames[kind] || kind;
      return `<article class="material-root-card" data-kind="${html(kind)}">
        <div><span>${html(componentName)}</span><b>${html(item.completeness === "COMPLETE" ? selected.componentComplete : item.completeness || selected.noValue)}</b></div>
        <strong>${html(format(selected.componentSource, { component: componentName }))}</strong>
        <small>${html(selected.exactVersionBound)}</small>
      </article>`;
    }).join("");
    const valueRows = values.map((item) => {
      const slot = String(item.slot_id || "").split(/[.:/]/).pop();
      const label = selected.slotNames[slot] || slot || item.object_ref || selected.noValue;
      const sensitivity = selected.sensitivityNames[String(item.sensitivity || "").toUpperCase()] || item.sensitivity || selected.noValue;
      const domainName = selected.domainNames[String(item.domain_id || "").toLowerCase()] || item.domain_id || selected.noValue;
      const rawValue = item.value === true
        ? (language === "en" ? "Yes" : "是")
        : item.value === false
          ? (language === "en" ? "No" : "否")
          : item.value;
      const displayValue = selected.materialValueNames[String(item.value)] || rawValue;
      return `<article class="material-value-card">
        <header><span>${html(label)}</span><b>${html(domainName)}</b></header>
        <strong>${html(displayValue)}</strong>
        <dl><div><dt>${html(selected.source)}</dt><dd>${html(format(selected.sourceRegistered, { domain: domainName }))}</dd></div>
        <div><dt>${html(selected.authority)}</dt><dd>${html(format(selected.authorityMatched, { domain: domainName }))}</dd></div>
        <div><dt>${html(selected.sensitivity)}</dt><dd>${html(sensitivity)}</dd></div></dl>
      </article>`;
    }).join("");
    const packRef = String(source.pack_ref || source.profile_ref || "").trim();
    const organizationRef = String(scenario.organization_id || profile.organization_id || "").trim();
    const packDisplayName = String(source.pack_display_name || profile.pack_display_name || "").trim()
      || selected.materialPackNames[packRef]
      || selected.materialPackName;
    const organizationDisplayName = String(scenario.organization_name || profile.organization_name || "").trim()
      || selected.organizationNames[organizationRef]
      || selected.materialOrganizationName;
    root.innerHTML = `
      <section class="material-identity">
        <article><span>${html(selected.pack)}</span><strong>${html(packDisplayName)}</strong><small>${html(selected.loadedByConfig)} · ${html(selected.exactVersionBound)}</small></article>
        <article><span>${html(selected.organization)}</span><strong>${html(organizationDisplayName)}</strong><small>${html(selected.profile)} · ${html(selected.exactVersionBound)}</small></article>
      </section>
      <section class="material-section"><header><div><span>${html(selected.fiveRoots)}</span><strong>${html(format(selected.rootCount, { count: components.length }))}</strong></div></header><div class="material-root-grid">${componentCards}</div></section>
      <section class="material-section"><header><div><span>${html(selected.facts)}</span><strong>${html(format(selected.factsCount, { count: values.length }))}</strong></div></header><div class="material-values-grid">${valueRows || `<p>${html(selected.noSource)}</p>`}</div></section>`;
  }

  function taskScope(state = currentState) {
    const lineage = state && state.enterprise_data_lineage || {};
    const source = lineage.source || {};
    const task = source.task || {};
    const scenario = state && state.scenario || {};
    return {
      actorId: String(task.actor_id || "").trim(),
      customerId: String(task.customer_id || scenario.customer_id || "").trim(),
      deliverableKind: String(task.deliverable_kind || "").trim(),
      templateRef: String(task.template_ref || "").trim(),
      taskRef: String(task.task_ref || scenario.task_id || "").trim(),
    };
  }

  function displayTaskActor(actorId) {
    if (!actorId) return "—";
    if (["employee:enterprise-quote-operator", "employee:sales-owner"].includes(actorId)) return copy().operator;
    return actorId;
  }

  function displayTaskCustomer(customerId) {
    if (!customerId) return "—";
    if (customerId === "customer:blue-harbor") return language === "en" ? "Blue Harbor" : "蓝港客户";
    return customerId;
  }

  function taskIntakeIssues(candidate) {
    const selected = copy();
    const reasons = Array.isArray(candidate && candidate.reason_codes) ? candidate.reason_codes : [];
    const unknowns = Array.isArray(candidate && candidate.unknowns) ? candidate.unknowns : [];
    const values = reasons.map((reason) => selected.taskReasonNames[reason] || selected.taskUnknownFallback);
    if (!values.length) unknowns.forEach((unknown) => values.push(selected.taskUnknownNames[unknown] || selected.taskUnknownFallback));
    return values;
  }

  function safeTaskIntakeError(error) {
    const selected = copy();
    const code = String(error && error.code || "");
    const message = String(error && error.message || "");
    const evidence = `${code} ${message}`.toUpperCase();
    if (evidence.includes("ACTOR") || evidence.includes("IDENTITY")) return selected.taskIdentityError;
    if (evidence.includes("OAC") || evidence.includes("CONTRACT")) return selected.taskContractError;
    return selected.taskError;
  }

  function taskIntakeHeaders(actorId) {
    const headers = { Accept: "application/json", "Content-Type": "application/json" };
    if (actorId) headers["X-OrgRebase-Actor"] = actorId;
    return headers;
  }

  async function taskIntakeApi(path, body, actorId) {
    const response = await window.fetch(path, {
      method: "POST",
      headers: taskIntakeHeaders(actorId),
      body: JSON.stringify(body),
    });
    let payload = null;
    try { payload = await response.json(); } catch (_) { payload = null; }
    if (!response.ok) {
      const detail = payload && payload.detail;
      const error = new Error(
        detail && typeof detail === "object" ? (detail.message || detail.code) : (detail || `HTTP ${response.status}`),
      );
      error.code = detail && typeof detail === "object" ? detail.code : `HTTP_${response.status}`;
      throw error;
    }
    return payload;
  }

  async function loadTaskWorkDescription(state, durableReceipt, actorId) {
    if (!durableReceipt || !actorId || taskWorkDescriptionStatus === "loading") return;
    taskWorkDescriptionRunId = durableReceipt.run_id;
    taskWorkDescriptionStatus = "loading";
    taskWorkDescription = null;
    renderTaskIntake(state);
    const headers = taskIntakeHeaders(actorId);
    delete headers["Content-Type"];
    try {
      const response = await window.fetch("/api/workspace/task-intake/work-description", {
        method: "GET",
        headers,
      });
      let payload = null;
      try { payload = await response.json(); } catch (_) { payload = null; }
      if (response.status === 404) {
        taskWorkDescriptionStatus = "not-retained";
      } else if (!response.ok) {
        taskWorkDescriptionStatus = "unavailable";
      } else if (
        !payload
        || payload.schema_version !== "orgrebase.workspace-task-intake-work-description-record.v1"
        || payload.status !== "PRIVATE_RECORD_RETAINED"
        || payload.run_id !== durableReceipt.run_id
        || payload.actor_id !== actorId
        || payload.prompt_digest !== durableReceipt.prompt_digest
        || payload.prompt_length !== durableReceipt.prompt_length
        || payload.candidate_digest !== durableReceipt.candidate_digest
        || payload.approval_digest !== durableReceipt.approval_digest
        || payload.formation_receipt_digest !== durableReceipt.formation_receipt_digest
        || payload.semantic_use !== "TASK_INTENT_ONLY"
        || payload.contributes_business_facts !== false
        || payload.grants_authority !== false
        || payload.included_in_public_evidence !== false
        || payload.included_in_events_or_otlp !== false
        || typeof payload.work_description !== "string"
      ) {
        taskWorkDescriptionStatus = "unavailable";
      } else {
        taskWorkDescription = payload.work_description;
        taskWorkDescriptionStatus = "available";
      }
    } catch (_) {
      taskWorkDescriptionStatus = "unavailable";
    }
    renderTaskIntake(currentState);
  }

  function setFormedWorkspaceVisibility(state = currentState) {
    const awaitingFormation = !state || state.stage === "EMPTY";
    const quotePage = pages.get("quote");
    if (!quotePage) return;
    [quotePage.querySelector(".journey"), byId("command-bar"), byId("workspace")].forEach((node) => {
      if (!node) return;
      node.hidden = awaitingFormation;
      node.setAttribute("aria-hidden", awaitingFormation ? "true" : "false");
    });
    const legacyPrimaryAction = byId("primary-action");
    if (legacyPrimaryAction && awaitingFormation) legacyPrimaryAction.disabled = true;
  }

  const DIGEST_PATTERN = /^sha256:[0-9a-f]{64}$/;

  function persistedTaskIntake(state) {
    const receipt = state && state.task_intake;
    const runId = state && state.execution && state.execution.run_id;
    if (!receipt || !runId || receipt.run_id !== runId) return null;
    if (
      receipt.schema_version !== "orgrebase.workspace-task-intake-run-receipt.v1"
      || receipt.status !== "FORMATION_COMPLETED"
      || receipt.intake_persisted !== true
      || receipt.intake_canonical_target_writes !== 0
      || receipt.formation_authority !== "ORGREBASE_CONTROL_PLANE"
      || receipt.claim_boundary !== "INTAKE_GATE_VERIFIED_THEN_EXISTING_CONTROL_PLANE_FORMED_QUOTE"
      || !Number.isSafeInteger(receipt.prompt_length)
      || receipt.prompt_length < 0
      || typeof receipt.quote_ref !== "string"
      || !receipt.quote_ref
      || typeof receipt.artifact_id !== "string"
      || !receipt.artifact_id
    ) return null;
    const requiredDigests = [
      receipt.digest,
      receipt.prompt_digest,
      receipt.candidate_digest,
      receipt.approval_digest,
      receipt.task_digest,
      receipt.formation_receipt_digest,
      receipt.artifact_payload_digest,
      receipt.event_digest,
    ];
    if (!requiredDigests.every((value) => DIGEST_PATTERN.test(String(value || "")))) return null;
    if (
      receipt.oac_activation_binding_digest != null
      && !DIGEST_PATTERN.test(String(receipt.oac_activation_binding_digest))
    ) return null;
    return receipt;
  }

  function renderTaskIntake(state = currentState) {
    const selected = copy();
    const root = byId("task-intake");
    const prompt = byId("task-request-prompt");
    const prepare = byId("task-intake-prepare");
    const candidatePanel = byId("task-intake-candidate");
    const admit = byId("task-intake-admit");
    const run = byId("task-intake-run");
    const privatePanel = byId("task-intake-private");
    const privateText = byId("task-intake-private-text");
    const contract = byId("task-intake-contract");
    const error = byId("task-intake-error");
    if (!root || !prompt || !prepare || !candidatePanel || !admit || !run || !privatePanel || !privateText || !contract || !error) return;

    const stateReady = stateAvailability === "ready" && state && STAGES.includes(state.stage);
    if (!stateReady) {
      const unavailable = stateAvailability === "unavailable";
      const status = unavailable ? selected.workspaceUnavailable : selected.workspaceLoading;
      root.dataset.contract = "blocked";
      root.dataset.complete = "false";
      root.dataset.availability = unavailable ? "unavailable" : "loading";
      contract.textContent = status;
      prompt.placeholder = selected.taskPromptExample;
      prompt.disabled = true;
      prepare.disabled = true;
      prepare.textContent = status;
      candidatePanel.hidden = false;
      candidatePanel.dataset.status = "hold";
      setExactText(byId("task-intake-candidate-status"), status);
      setExactText(byId("task-intake-candidate-badge"), status);
      setExactText(byId("task-intake-template"), "—");
      setExactText(byId("task-intake-digest"), "—");
      setExactText(byId("task-intake-unknowns"), status);
      admit.hidden = true;
      admit.disabled = true;
      run.hidden = true;
      run.disabled = true;
      error.hidden = true;
      error.textContent = "";
      privatePanel.hidden = true;
      setFormedWorkspaceVisibility(null);
      return;
    }

    const scope = taskScope(state);
    const formed = state.stage !== "EMPTY";
    if (!formed && taskWorkDescriptionRunId !== null) {
      taskWorkDescription = null;
      taskWorkDescriptionRunId = null;
      taskWorkDescriptionStatus = "idle";
    }
    const durableReceipt = formed ? persistedTaskIntake(state) : null;
    const intakeEvidenceMissing = formed && !durableReceipt;
    const contractReady = organizationContractReady(state);
    const hasExactScope = Boolean(scope.actorId && scope.customerId && scope.deliverableKind);
    delete root.dataset.availability;
    root.dataset.contract = contractReady ? "ready" : "blocked";
    root.dataset.complete = formed ? "true" : "false";
    byId("task-intake-kicker").textContent = formed ? selected.taskCompletedKicker : selected.taskIntakeKicker;
    byId("task-intake-title").textContent = formed ? selected.taskCompletedTitle : selected.taskIntakeTitle;
    byId("task-intake-body").textContent = formed ? selected.taskCompletedBody : selected.taskIntakeBody;
    contract.textContent = contractReady ? selected.taskContractReady : selected.taskContractBlocked;
    prompt.placeholder = selected.taskPromptExample;
    prompt.disabled = taskIntakeBusy || formed || !contractReady;
    privatePanel.hidden = !formed;
    if (formed) {
      if (!durableReceipt) {
        taskWorkDescriptionRunId = null;
        taskWorkDescriptionStatus = "not-retained";
        taskWorkDescription = null;
      } else if (taskWorkDescriptionRunId !== durableReceipt.run_id) {
        taskWorkDescriptionRunId = durableReceipt.run_id;
        taskWorkDescriptionStatus = "idle";
        taskWorkDescription = null;
      }
      privatePanel.dataset.status = taskWorkDescriptionStatus;
      privateText.textContent = taskWorkDescriptionStatus === "available"
        ? taskWorkDescription
        : taskWorkDescriptionStatus === "not-retained"
          ? selected.taskPrivateNotRetained
          : taskWorkDescriptionStatus === "unavailable"
            ? selected.taskPrivateUnavailable
            : selected.taskPrivateLoading;
      if (durableReceipt && taskWorkDescriptionStatus === "idle") {
        window.setTimeout(() => loadTaskWorkDescription(state, durableReceipt, scope.actorId), 0);
      }
    }
    byId("task-intake-actor").textContent = displayTaskActor(scope.actorId);
    byId("task-intake-actor").removeAttribute("title");
    byId("task-intake-customer").textContent = displayTaskCustomer(scope.customerId);
    byId("task-intake-customer").removeAttribute("title");
    prepare.disabled = taskIntakeBusy || formed || Boolean(taskCandidate) || (contractReady && (!hasExactScope || !prompt.value.trim()));
    prepare.textContent = !contractReady
      ? selected.taskCompleteOnboarding
      : taskIntakeBusy && taskIntakeAction === "prepare"
        ? selected.taskPreparing
        : selected.taskPrepare;
    error.hidden = !taskIntakeError;
    error.textContent = taskIntakeError || "";
    setFormedWorkspaceVisibility(state);

    if (!taskCandidate && !formed) {
      candidatePanel.hidden = true;
      return;
    }

    candidatePanel.hidden = false;
    const candidateReady = Boolean(taskCandidate && taskCandidate.status === "READY_FOR_CONFIRMATION");
    const candidateHold = Boolean(taskCandidate && taskCandidate.status === "HOLD");
    const status = formed
      ? (intakeEvidenceMissing ? selected.taskEvidenceUnavailable : selected.taskStarted)
      : taskApproval
        ? (taskIntakeError && !taskIntakeBusy ? selected.taskAdmittedRetry : selected.taskAdmitted)
        : candidateReady
          ? selected.taskCandidateReady
          : selected.taskCandidateHold;
    candidatePanel.dataset.status = formed ? (intakeEvidenceMissing ? "hold" : "complete") : candidateHold ? "hold" : "ready";
    setExactText(
      byId("task-intake-candidate-status"),
      status,
      durableReceipt
        ? [durableReceipt.run_id, durableReceipt.artifact_id, durableReceipt.event_digest].join(" · ")
        : null,
    );

    const promptDigest = durableReceipt && durableReceipt.prompt_digest || taskCandidate && taskCandidate.prompt_digest;
    const promptLength = durableReceipt
      ? durableReceipt.prompt_length
      : taskCandidate && taskCandidate.prompt_length;
    const inputProof = promptDigest
      ? format(selected.taskInputProof, { length: Number(promptLength || 0) })
      : (formed ? selected.taskEvidenceUnavailable : selected.taskStartedBadge);
    setExactText(byId("task-intake-candidate-badge"), inputProof, promptDigest);
    const templateRef = formed
      ? scope.templateRef
      : taskCandidate && taskCandidate.template_ref || scope.templateRef;
    setExactText(byId("task-intake-template"), templateRef ? selected.taskTemplateValue : "—", templateRef || null);

    const binding = durableReceipt
      ? selected.taskChainProof
      : formed
        ? "—"
        : taskApproval
          ? (taskIntakeError && !taskIntakeBusy ? selected.taskAdmittedRetryProof : selected.taskAdmittedProof)
          : candidateHold
            ? selected.taskHoldProof
            : taskCandidate && taskCandidate.digest ? selected.taskCandidateProof : null;
    setExactText(
      byId("task-intake-digest"),
      binding || "—",
      durableReceipt
        ? [
            durableReceipt.digest,
            durableReceipt.candidate_digest,
            durableReceipt.approval_digest,
            durableReceipt.task_digest,
            durableReceipt.formation_receipt_digest,
            durableReceipt.artifact_payload_digest,
            durableReceipt.event_digest,
          ].join(" · ")
        : binding,
    );
    const activationDigest = durableReceipt && durableReceipt.oac_activation_binding_digest
      || (!formed && taskCandidate && taskCandidate.oac_activation_binding_digest);
    const issues = taskIntakeIssues(taskCandidate);
    byId("task-intake-third-label").textContent = formed
      ? selected.taskConstraintLabel
      : candidateHold
        ? selected.taskHoldReasonLabel
        : selected.taskStartPrerequisitesLabel;
    byId("task-intake-unknowns").textContent = formed
      ? (intakeEvidenceMissing
        ? selected.taskEvidenceUnavailableDetail
        : activationDigest
          ? selected.taskOacBound
          : selected.taskOacOptional)
      : (issues.length ? issues.join("；") : selected.taskNoUnknowns);
    byId("task-intake-unknowns").removeAttribute("title");
    admit.hidden = formed;
    admit.disabled = taskIntakeBusy || !candidateReady || candidateHold || Boolean(taskApproval);
    admit.textContent = taskApproval
      ? selected.taskAdmittedButton
      : taskIntakeBusy && taskIntakeAction === "admit"
        ? selected.taskAdmitting
        : selected.taskAdmit;
    run.hidden = formed || !taskApproval;
    run.disabled = taskIntakeBusy || !taskApproval;
    run.textContent = taskIntakeBusy && taskIntakeAction === "run"
      ? selected.taskRunning
      : selected.taskRun;
  }

  async function prepareTaskIntake() {
    if (taskIntakeBusy || currentState && currentState.stage !== "EMPTY") return;
    if (!organizationContractReady(currentState)) {
      navigate("oac");
      return;
    }
    const prompt = byId("task-request-prompt");
    const scope = taskScope(currentState);
    if (!prompt || !prompt.value.trim() || !scope.actorId || !scope.customerId || !scope.deliverableKind) return;
    taskCandidate = null;
    taskApproval = null;
    taskIntakeError = null;
    taskIntakeBusy = true;
    taskIntakeAction = "prepare";
    renderTaskIntake(currentState);
    try {
      taskCandidate = await taskIntakeApi("/api/workspace/task-intake/prepare", {
        prompt: prompt.value,
        actor_id: scope.actorId,
        customer_id: scope.customerId,
        deliverable_kind: scope.deliverableKind,
      }, scope.actorId);
    } catch (requestError) {
      taskIntakeError = safeTaskIntakeError(requestError);
    } finally {
      taskIntakeBusy = false;
      taskIntakeAction = "idle";
      renderTaskIntake(currentState);
      renderContextFacts(currentState);
      renderOverviewFlow(currentState);
    }
  }

  async function admitTaskIntake() {
    if (taskIntakeBusy || !taskCandidate || taskCandidate.status !== "READY_FOR_CONFIRMATION") return;
    const scope = taskScope(currentState);
    if (taskApproval) return;
    taskIntakeError = null;
    taskIntakeBusy = true;
    taskIntakeAction = "admit";
    renderTaskIntake(currentState);
    try {
      taskApproval = await taskIntakeApi("/api/workspace/task-intake/admit", {
        actor_id: scope.actorId,
        candidate_receipt: taskCandidate,
        candidate_digest: taskCandidate.digest,
      }, scope.actorId);
    } catch (requestError) {
      taskIntakeError = safeTaskIntakeError(requestError);
    } finally {
      taskIntakeBusy = false;
      taskIntakeAction = "idle";
      renderTaskIntake(currentState);
    }
  }

  async function runTaskIntake() {
    if (
      taskIntakeBusy
      || !taskCandidate
      || taskCandidate.status !== "READY_FOR_CONFIRMATION"
      || !taskApproval
    ) return;
    const scope = taskScope(currentState);
    const prompt = byId("task-request-prompt");
    if (!prompt || !prompt.value) return;
    taskIntakeError = null;
    taskIntakeBusy = true;
    taskIntakeAction = "run";
    renderTaskIntake(currentState);
    try {
      const result = await taskIntakeApi("/api/workspace/task-intake/run", {
        actor_id: scope.actorId,
        candidate_receipt: taskCandidate,
        candidate_digest: taskCandidate.digest,
        approval_receipt: taskApproval,
        approval_digest: taskApproval.digest,
        work_description: prompt.value,
      }, scope.actorId);
      const formedState = result && result.state || null;
      if (formedState) {
        currentState = formedState;
        renderState(formedState);
      }
      if (typeof window.refreshState === "function") await window.refreshState();
      else if (formedState && typeof window.render === "function") window.render(formedState);
      window.dispatchEvent(new CustomEvent("orgrebase:workspacechange", {
        detail: { stage: formedState && formedState.stage || "QUOTE_V1", source: "task-intake" },
      }));
    } catch (requestError) {
      taskIntakeError = safeTaskIntakeError(requestError);
    } finally {
      taskIntakeBusy = false;
      taskIntakeAction = "idle";
      renderTaskIntake(currentState);
    }
  }

  function bindTaskIntake() {
    const prompt = byId("task-request-prompt");
    const prepare = byId("task-intake-prepare");
    const admit = byId("task-intake-admit");
    const run = byId("task-intake-run");
    if (!prompt || !prepare || !admit || !run || prepare.dataset.bound) return;
    prepare.dataset.bound = "true";
    prepare.addEventListener("click", prepareTaskIntake);
    admit.addEventListener("click", admitTaskIntake);
    run.addEventListener("click", runTaskIntake);
    prompt.addEventListener("input", () => {
      if (taskIntakeBusy) return;
      taskCandidate = null;
      taskApproval = null;
      taskIntakeError = null;
      renderTaskIntake(currentState);
    });
  }

  function focusTaskIntake() {
    navigate("quote");
    window.setTimeout(() => {
      const panel = byId("task-intake");
      const prompt = byId("task-request-prompt");
      if (panel && typeof panel.scrollIntoView === "function") {
        panel.scrollIntoView({ behavior: "smooth", block: "start" });
      }
      if (prompt && !prompt.disabled && typeof prompt.focus === "function") {
        prompt.focus({ preventScroll: true });
      }
    }, 0);
  }

  function renderState(state, { availability = null } = {}) {
    if (state && STAGES.includes(state.stage)) {
      currentState = state;
      stateAvailability = "ready";
    } else if (state != null) {
      currentState = null;
      stateAvailability = "unavailable";
    } else if (!currentState && availability === "unavailable") {
      stateAvailability = "unavailable";
    } else if (!currentState && stateAvailability !== "unavailable") {
      stateAvailability = "loading";
    }
    const selected = copy();
    const projectedState = stateAvailability === "ready" ? currentState : null;
    if (currentRoute === "overview") {
      activeLifecycle = organizationContractReady(projectedState) ? "daily" : "onboarding";
      renderLifecycle();
    }
    renderContextFacts(projectedState);
    ROUTES.forEach((route) => {
      const button = document.querySelector(`.shell-nav-item[data-route="${route.id}"]`);
      if (!button) return;
      const status = projectedState ? navState(route.id, projectedState) : stateAvailability;
      const label = button.querySelector(".shell-nav-state");
      label.textContent = selected.navState[status];
      label.dataset.state = status;
    });
    renderOverviewFlow(projectedState);
    renderMaterials(projectedState);
    renderTaskIntake(projectedState);
    positionCurrentRunProof();
  }

  function boot() {
    buildShell();
    if (!shell) return;
    positionPlatformGovernance();
    positionCurrentRunProof();
    bindTaskIntake();
    setCopy();
    currentRoute = routeFromHash();
    activate(currentRoute);
    window.addEventListener("hashchange", () => activate(routeFromHash(), { focus: true }));
    window.addEventListener("orgrebase:languagechange", (event) => {
      language = event.detail && event.detail.language === "en" ? "en" : "zh-CN";
      setCopy();
    });
    window.addEventListener("orgrebase:staterendered", (event) => renderState(event.detail || null));
    window.addEventListener("orgrebase:stateunavailable", () => {
      if (!currentState) renderState(null, { availability: "unavailable" });
    });
    window.addEventListener("orgrebase:workspacechange", () => {
      window.fetch("/api/workspace/state", { headers: { Accept: "application/json" } })
        .then((response) => {
          if (!response.ok) throw new Error(`HTTP ${response.status}`);
          return response.json();
        })
        .then((state) => renderState(state))
        .catch(() => { if (!currentState) renderState(null, { availability: "unavailable" }); });
    });
    window.addEventListener("orgrebase:oacadaptationchange", (event) => {
      currentOac = event.detail || null;
      renderState(currentState);
    });
    window.fetch("/api/workspace/state", { headers: { Accept: "application/json" } })
      .then((response) => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return response.json();
      })
      .then((state) => renderState(state))
      .catch(() => { if (!currentState) renderState(null, { availability: "unavailable" }); });
  }

  window.OrgRebaseWorkspaceShell = Object.freeze({
    navigate,
    focusTaskIntake,
    currentRoute: () => currentRoute,
  });
  boot();
})();
